/* Kurdish Businessman — translation store (filled by js/lang/*.js) */
const T={};
