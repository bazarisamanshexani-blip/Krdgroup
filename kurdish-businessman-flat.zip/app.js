/* Kurdish Businessman — application logic (state, rendering, events, PDF export) */
(function(){
'use strict';
/* ---------- helpers ---------- */
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=(v,d=0)=>Number(v).toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d});
const fmtP=v=>fmt(v,Math.abs(v%1)<1e-9?0:2);
const usd=(v,d=0)=>{const r=Number(Math.abs(v).toFixed(d));return (v<0&&r>0?'-':'')+'$'+fmt(r,d)};
const num=h=>'<span class="num">'+h+'</span>';
const pad=(n,l=3)=>String(n).padStart(l,'0');
const today=new Date();
const iso=d=>{const z=new Date(d.getTime()-d.getTimezoneOffset()*6e4);return z.toISOString().slice(0,10)};
const addDays=(d,n)=>{const x=new Date(d);x.setDate(x.getDate()+Math.round(n));return x};
const stamp=()=>{const n=new Date();return iso(n)+' · '+pad(n.getHours(),2)+':'+pad(n.getMinutes(),2)};
const niceCeil=v=>{const p=Math.pow(10,Math.floor(Math.log10(v)));const m=v/p;return (m<=1?1:m<=2?2:m<=5?5:10)*p};
const kfmt=v=>v>=1000?'$'+(Math.round(v/100)/10)+'k':'$'+Math.round(v);

const bi=k=>(S.lang==='ar'?T.ar:T.ku)[k]+' · '+T.en[k];
function t(k,v){let s=(T[S.lang]&&T[S.lang][k]);if(s==null)s=T.en[k];if(s==null)s=k;if(v)for(const x in v)s=s.replace('{'+x+'}',v[x]);return s}


/* ---------- data ---------- */
const STORE='kb-logistics-v1';
const NAV=['dashboard','shipments','merchants','debts','profit','team'];
const PAGES=NAV.concat('profile','received','sales','expenses','assets');
const PAGE_IC={dashboard:'dash',shipments:'box',merchants:'users',debts:'wallet',profit:'chart',team:'shield'};
const SECTIONS=['dashboard','shipments','merchants','debts','profit'];
const S={lang:'ku',page:'dashboard',user:null,auth:null,data:null,modal:null,f:{q:'',status:'all',mode:'all',mq:'',period:'all',from:'',to:'',repMer:'',dq:'',owing:false,sq:''}};

function rng(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function seed(){
  const r=rng(20261003);
  const merchants=MER.map((m,i)=>({id:'M'+pad(i+1),code:100+i,en:m[0],ku:m[1],city:m[2],phone:'+964 '+['750','751','770','771'][i%4]+' '+pad(100+(i*37)%800)+' '+(1000+(i*251)%9000),notes:''}));
  const goodsK=Object.keys(GOODS),origK=Object.keys(ORIGINS),codes=[];
  for(let i=1;i<=68;i++){
    const p=r(),mode=p<.55?'sea':p<.82?'air':'land';
    const ago=Math.round((68-i)*0.95+r()*1.2)+2,buy=addDays(today,-ago);
    let wQty=0,wCost=0,cQty=0,cCost=0;
    if(mode==='sea'){cQty=+(8+r()*52).toFixed(1);cCost=Math.round(92+r()*58)}
    else if(mode==='air'){wQty=Math.round(150+r()*2350);wCost=+(4+r()*3).toFixed(2)}
    else{wQty=Math.round(1200+r()*6800);wCost=+(.9+r()*.7).toFixed(2);cQty=+(8+r()*30).toFixed(1);cCost=Math.round(38+r()*30)}
    const wh=2+r()*3,dep=wh+3+r()*4,tr=dep+2+r()*3,td=mode==='sea'?30+r()*10:mode==='air'?5+r()*4:12+r()*6;
    const offs=[0,wh,dep,tr,dep+td].map(Math.round);
    let st=0;for(let k=1;k<5;k++)if(ago>=offs[k])st=k;
    const dates=offs.map((o,k)=>k<=st?iso(addDays(buy,o)):null);
    const sales=[],target=st===4?(r()<.6?1:.75+r()*.25):(r()<.65?.25+r()*.6:0);
    if(target>0){
      const ns=st===4?1+Math.floor(r()*3.4):1+Math.floor(r()*2.2),pool=merchants.slice(),pick=[];
      for(let k=0;k<ns;k++)pick.push(pool.splice(Math.floor(r()*pool.length),1)[0]);
      const sh=pick.map(()=>.3+r()),sum=sh.reduce((x,y)=>x+y,0);
      const wBase=wCost*(1.12+r()*.28),cBase=cCost*(1.12+r()*.28);
      pick.forEach((m,k)=>{
        const f=target*sh[k]/sum,wq=Math.floor(wQty*f),cq=Math.floor(cQty*f*10)/10;
        if(wq<=0&&cq<=0)return;
        const v=()=>1+(r()-.5)*.08;
        sales.push({id:'S'+pad(i)+k,merchantId:m.id,wQty:wq,wPrice:wq?+(wBase*v()).toFixed(2):0,cQty:cq,cPrice:cq?Math.round(cBase*v()):0,date:iso(addDays(buy,Math.min(ago,2+r()*18)))});
      });
    }
    const trk=mode==='sea'?'MEDU'+Math.floor(1e6+r()*9e6):mode==='air'?'176-'+Math.floor(1e7+r()*9e7):'CN-IQ-'+Math.floor(1e5+r()*9e5);
    codes.push({id:'KB-'+pad(i),track:String(trk),mode,goods:goodsK[Math.floor(r()*goodsK.length)],origin:origK[Math.floor(r()*origK.length)],dest:DESTS[Math.floor(r()*DESTS.length)],buy:iso(buy),status:st,dates,wQty,wCost,cQty,cCost,notes:'',sales});
  }
  const all={dashboard:1,shipments:1,merchants:1,debts:1,profit:1,team:1};
  const members=[
    {id:'U1',en:'Rebin Karim',ku:'ڕێبین کەریم',email:'rebin@kurdishbusinessman.example',role:'manager',pw:'demo1234',perms:all},
    {id:'U2',en:'Shilan Ahmed',ku:'شیلان ئەحمەد',email:'shilan@kurdishbusinessman.example',role:'admin',pw:'demo1234',perms:{dashboard:1,shipments:1,merchants:1,debts:1,profit:0,team:0}},
    {id:'U3',en:'Dara Mohammed',ku:'دارا محەمەد',email:'dara@kurdishbusinessman.example',role:'admin',pw:'demo1234',perms:{dashboard:0,shipments:1,merchants:1,debts:0,profit:0,team:0}},
    {id:'U4',en:'Lava Hassan',ku:'لاڤا حەسەن',email:'lava@kurdishbusinessman.example',role:'admin',pw:'demo1234',perms:{dashboard:1,shipments:0,merchants:0,debts:0,profit:1,team:0}}];
  const data={merchants,codes,members};assignOwners(data);data.payments=seedPayments(merchants,codes,r);
  return data;
}
function assignOwners(data){
  const ms=data.merchants;
  data.codes.forEach(c=>{
    if(c.merchantId&&ms.find(m=>m.id===c.merchantId))return;
    const f=c.sales&&c.sales[0],num=parseInt(String(c.id).replace(/\D/g,''),10)||0;
    c.merchantId=f?f.merchantId:ms[(num*7)%ms.length].id;
  });
  data.codes.slice().sort((a,b)=>String(a.buy).localeCompare(String(b.buy))||String(a.id).localeCompare(String(b.id))).forEach(c=>{
    if(/^\d+-\d+$/.test(c.id))return;
    const base=ms.find(m=>m.id===c.merchantId).code;let n=1;
    while(data.codes.some(x=>x.id===base+'-'+pad(n,3)))n++;
    c.id=base+'-'+pad(n,3);
  });
}
function seedPayments(merchants,codes,r){
  const out=[];let n=0;
  merchants.forEach(m=>{
    let sold=0,first='';
    codes.forEach(c=>c.sales.forEach(s=>{if(s.merchantId===m.id){sold+=s.wQty*s.wPrice+s.cQty*s.cPrice;if(!first||s.date<first)first=s.date}}));
    if(sold<=0)return;
    const p=r(),f=p<.35?1:p<.8?.4+r()*.5:r()*.3,k=1+Math.floor(r()*3);
    const parts=Array.from({length:k},()=>.3+r()),sum=parts.reduce((x,y)=>x+y,0);
    parts.forEach((x,i)=>{
      const amt=Math.floor(sold*f*x/sum/10)*10;if(amt<=0)return;
      let d=iso(addDays(new Date(first+'T12:00:00'),3+i*9+r()*6));if(d>iso(today))d=iso(today);
      out.push({id:'P'+pad(++n,4),merchantId:m.id,amount:amt,date:d,note:''});
    });
  });
  return out;
}

function seedFinance(){
  const r=rng(4242);
  const A=[['Electric forklift',4800,-170],['Warehouse racking system',3200,-165],['Office furniture',1900,-150],['Office laptops (3)',2700,-120],['Delivery van',16500,-100],['Security cameras & recorder',1450,-80],['Label printer & scanners',620,-45]];
  const assets=A.map((a,i)=>({id:'A'+pad(i+1,2),name:a[0],amount:a[1],date:iso(addDays(today,a[2])),notes:''}));
  const expenses=[];let n=1;
  for(let k=5;k>=0;k--){
    const ym=iso(new Date(today.getFullYear(),today.getMonth()-k,1)).slice(0,7);
    const add=(day,title,cat,amt)=>{const ds=ym+'-'+pad(day,2);if(ds<=iso(today))expenses.push({id:'E'+pad(n++,3),title,cat,amount:amt,date:ds,notes:''})};
    add(1,'Warehouse rent','rent',1800);add(3,'Electricity & generator','utilities',Math.round(240+r()*120));add(5,'Internet & phones','utilities',85);
    add(9,'Fuel & local transport','transport',Math.round(280+r()*160));add(14,'Cleaning & supplies','supplies',Math.round(60+r()*50));
    add(20,k%2?'Social media ads':'Printing & packaging','marketing',Math.round(120+r()*120));
    if(k%3===0)add(24,'Vehicle & forklift maintenance','maintenance',Math.round(150+r()*150));
  }
  return {assets,expenses};
}
function ensureFinance(d){
  if(!d.assets||!d.expenses){const f=seedFinance();if(!d.assets)d.assets=f.assets;if(!d.expenses)d.expenses=f.expenses}
  if(!d.salMig){d.salMig=1;const ymNow=iso(today).slice(0,7);d.members.forEach(m=>{const sal=({U2:800,U3:700,U4:750})[m.id]||0;if(!(sal>0))return;let y=+iso(addDays(today,-150)).slice(0,4),mo=+iso(addDays(today,-150)).slice(5,7);for(let g=0;g<24;g++){const ym=y+'-'+pad(mo,2);if(ym>=ymNow)break;d.expenses.push({id:'SP-'+m.id+'-'+ym,title:m.en||m.ku,cat:'salary',memberId:m.id,month:ym,amount:sal,date:ym+'-28',notes:''});mo++;if(mo>12){mo=1;y++}}})}
  d.members.forEach(m=>{if(m.salary===undefined)m.salary=({U2:800,U3:700,U4:750})[m.id]||0;if(!m.since)m.since=iso(addDays(today,-150)).slice(0,7)});
}
const EXP_CATS=['rent','utilities','transport','marketing','maintenance','supplies','other'];
function salaryRows(){
  const rows=[],ymNow=iso(today).slice(0,7);
  S.data.members.forEach(m=>{
    if(!(m.salary>0))return;
    let y=+(m.since||ymNow).slice(0,4),mo=+(m.since||ymNow).slice(5,7);
    for(let g=0;g<240;g++){const ym=y+'-'+pad(mo,2);if(ym>ymNow)break;rows.push({id:'sal-'+m.id+'-'+ym,kind:'salary',member:m,title:pName(m),cat:'salary',amount:m.salary,date:ym+'-01',notes:''});mo++;if(mo>12){mo=1;y++}}
  });
  return rows;
}
function ensureReceipts(d){
  if(!d.receipts){d.receipts=[];d.codes.forEach(c=>{const rs=c.receipts&&c.receipts.length?c.receipts:((c.wQty||c.cQty)?[{id:'R-'+c.id,date:c.buy,w:c.wQty||0,c:c.cQty||0}]:[]);rs.forEach(r=>d.receipts.push({id:r.id,date:r.date,w:+r.w||0,c:+r.c||0,note:c.id}))})}
  d.codes.forEach(c=>{delete c.receipts});
}
function load(){try{const j=JSON.parse(localStorage.getItem(STORE));if(j&&j.v===1&&j.data&&j.data.codes){S.data=j.data;if(j.lang)S.lang=j.lang}}catch(e){}if(!S.data)S.data=seed();S.data.members.forEach(m=>{if(!m.pw)m.pw='demo1234';if(m.perms.debts===undefined)m.perms.debts=0});if(!S.data.payments)S.data.payments=seedPayments(S.data.merchants,S.data.codes,rng(777));
  {let mx=99;S.data.merchants.forEach(m=>{if(m.code!=null&&m.code>mx)mx=m.code});S.data.merchants.slice().sort((a,b)=>a.id.localeCompare(b.id)).forEach(m=>{if(m.code==null)m.code=++mx})}
  assignOwners(S.data);ensureReceipts(S.data);ensureFinance(S.data);try{const sid=localStorage.getItem('kb-session');if(sid&&S.data.members.find(m=>m.id===sid)){S.auth=S.user=sid}}catch(e){}}
function save(){try{localStorage.setItem(STORE,JSON.stringify({v:1,lang:S.lang,data:S.data}))}catch(e){}}

const mer=id=>S.data.merchants.find(m=>m.id===id);
const codeOf=id=>S.data.codes.find(c=>c.id===id);
const me=()=>S.data.members.find(m=>m.id===S.user)||S.data.members[0];
const can=p=>{if(p==='profile')return true;const key=({received:'shipments',sales:'shipments',expenses:'profit',assets:'profit'})[p]||p;const u=me();return u.role==='manager'||(key!=='team'&&!!u.perms[key])};
const pickL=pair=>S.lang==='ku'?pair[1]:S.lang==='ar'?(AR_MAP[pair[0]]||pair[1]):pair[0];
const pName=m=>(S.lang==='en'?(m.en||m.ku):(m.ku||m.en))||'—';
const mName=m=>m?pName(m):'—';

function calc(c){
  let wq=0,cq=0,wr=0,cr=0;
  c.sales.forEach(s=>{wq+=s.wQty;cq+=s.cQty;wr+=s.wQty*s.wPrice;cr+=s.cQty*s.cPrice});
  const lumpRev=+c.tSale||0,lumpCost=+c.tCost||0,rev=wr+cr+lumpRev,lumpCostSold=rev>0?lumpCost:0;
  const costTotal=c.wQty*c.wCost+c.cQty*c.cCost+lumpCost,costSold=wq*c.wCost+cq*c.cCost+lumpCostSold;
  return {lumpRev,lumpCost,lumpCostSold,wSold:wq,cSold:cq,wRev:wr,cRev:cr,rev,costTotal,costSold,profit:rev-costSold,margin:rev?(rev-costSold)/rev:0,
    wLeft:Math.round((c.wQty-wq)*100)/100,cLeft:Math.round((c.cQty-cq)*100)/100,wAvg:wq?wr/wq:0,cAvg:cq?cr/cq:0};
}
function agg(codes){
  const a={wB:0,wS:0,cB:0,cS:0,wCostB:0,cCostB:0,wRev:0,cRev:0,rev:0,costSold:0,profit:0,costTotal:0};
  codes.forEach(c=>{const k=calc(c);a.wB+=c.wQty;a.cB+=c.cQty;a.wCostB+=c.wQty*c.wCost;a.cCostB+=c.cQty*c.cCost;a.wS+=k.wSold;a.cS+=k.cSold;a.wRev+=k.wRev;a.cRev+=k.cRev;a.rev+=k.rev;a.costSold+=k.costSold;a.profit+=k.profit;a.costTotal+=k.costTotal});
  return a;
}
const av=(m,cls)=>'<span class="avatar'+(cls?' '+cls:'')+'">'+(m.photo?'<img src="'+m.photo+'" alt="">':esc([...pName(m)][0]))+'</span>';
const nextMerCode=()=>Math.max(99,...S.data.merchants.map(m=>m.code||0))+1;
const findMer=txt=>{txt=String(txt||'').trim().toLowerCase();if(!txt)return null;const ms=S.data.merchants;const cm=txt.match(/^(\d+)/);if(cm){const x=ms.find(m=>m.code===+cm[1]);if(x)return x}const ex=ms.find(m=>(m.en||'').toLowerCase()===txt||(m.ku||'')===txt||(m.code+' · '+mName(m)).toLowerCase()===txt);if(ex)return ex;const part=ms.filter(m=>((m.en||'')+' '+(m.ku||'')).toLowerCase().includes(txt));return part.length===1?part[0]:null};
const nextCodeFor=mid=>{const m=mer(mid);let n=1;while(S.data.codes.some(x=>x.id===m.code+'-'+pad(n,3)))n++;return m.code+'-'+pad(n,3)};

/* ---------- small renderers ---------- */
const stPill=s=>'<span class="pill st'+s+'">'+t('st'+s)+'</span>';
const modeTag=m=>'<span class="mode">'+ic(m==='sea'?'ship':m==='air'?'plane':'truck')+t('mode_'+m)+'</span>';
const profitCls=v=>v>0?'pos':v<0?'neg':'';
const goodsName=c=>pickL(GOODS[c.goods]);
function qtyCell(sold,total,unit,d){
  if(!total)return '<span class="sub2">—</span>';
  const pct=Math.min(100,sold/total*100);
  return '<div class="qty"><span>'+num('<b>'+fmt(sold,d)+'</b>')+' <small>/ '+num(fmt(total,d))+' '+unit+'</small></span><div class="bar"><i style="width:'+pct+'%"></i></div></div>';
}
function fld(id,label,inner,cls){return '<label class="fld'+(cls?' '+cls:'')+'" for="'+id+'"><span>'+label+'</span>'+inner+'</label>'}
const inp=(id,val,attrs)=>'<input id="'+id+'" name="'+id+'" value="'+esc(val)+'" '+(attrs||'')+'>';
const merLabel=m=>m.code+' · '+mName(m);
function merItems(q){
  q=String(q||'').trim().toLowerCase();
  const ms=S.data.merchants.slice().sort((a,b)=>a.code-b.code).filter(m=>!q||(String(m.code)+' '+(m.en||'')+' '+(m.ku||'')+' '+(m.phone||'')).toLowerCase().includes(q));
  return ms.length?ms.map(m=>'<button type="button" class="mp-i" data-act="pick-mer" data-id="'+m.code+'"><b class="mono">'+m.code+'</b><span>'+esc(mName(m))+'</span></button>').join(''):'<div class="mp-none">'+t('no_results')+'</div>';
}
function merPicker(m){
  return '<div class="mpick"><input type="hidden" id="f-cmer" name="f-cmer" value="'+(m?m.code:'')+'">'+
  '<input type="text" id="mp-q" name="mp-q" autocomplete="off" inputmode="search" enterkeyhint="search" value="'+esc(m?merLabel(m):'')+'" placeholder="'+t('merchant_hint')+'">'+
  '<div class="mp-list" id="mp-list" hidden></div></div>';
}
const sel=(id,opts,val)=>'<select id="'+id+'" name="'+id+'">'+opts.map(o=>'<option value="'+o[0]+'"'+(o[0]===val?' selected':'')+'>'+esc(o[1])+'</option>').join('')+'</select>';

/* ---------- shell ---------- */
function navHTML(kind){
  return NAV.filter(can).map(p=>{
    const cur=(S.page===p||(p==='shipments'&&(S.page==='received'||S.page==='sales'))||(p==='profit'&&(S.page==='expenses'||S.page==='assets')))?' aria-current="page"':'';
    return '<button data-act="nav" data-id="'+p+'"'+cur+'>'+ic(PAGE_IC[p])+'<span>'+t('nav_'+p)+'</span></button>';
  }).join('');
}
function renderApp(){
  const root=document.documentElement;
  root.lang=S.lang==='ku'?'ckb':S.lang==='ar'?'ar':'en';root.dir=S.lang==='en'?'ltr':'rtl';
  $('#app').className=S.auth?'app':'login';
  if(!S.auth){renderLogin();$('#modal-root').innerHTML='';document.body.style.overflow='';return}
  const u=me();
  const prev=S.user!==S.auth?'<div class="preview"><span>'+t('previewing',{n:esc(pName(u))})+'</span><button class="btn sm" data-act="backmgr">'+t('back_manager')+'</button></div>':'';
  $('#app').innerHTML=
  '<aside class="rail"><span class="logo" role="img" aria-label="'+t('brand')+'"></span>'+
  '<nav class="nav" aria-label="'+t('brand')+'">'+navHTML()+'</nav>'+
  '<div class="rail-foot"><p>'+t('sample_note')+'</p><button class="rail-btn" data-act="reset">'+t('reset')+'</button><p class="tag">Elevating · Inspiring Trust · Creating Opportunities</p></div></aside>'+
  '<div class="main"><header class="topbar"><span class="logo" role="img" aria-label="'+t('brand')+'"></span>'+
  '<div class="top-actions"><div class="seg" role="group"><button data-act="lang" data-id="ku" aria-pressed="'+(S.lang==='ku')+'">'+T.ku.lang_ku+'</button><button data-act="lang" data-id="ar" aria-pressed="'+(S.lang==='ar')+'">'+T.ku.lang_ar+'</button><button data-act="lang" data-id="en" aria-pressed="'+(S.lang==='en')+'">English</button></div>'+
  (S.user===S.auth?'<button class="who" data-act="nav" data-id="profile" aria-label="'+t('profile_title')+'">':'<div class="who">')+av(u)+'<div><b>'+esc(pName(u))+'</b><small>'+t(u.role==='manager'?'role_manager':'role_admin')+'</small></div>'+(S.user===S.auth?'</button>':'</div>')+'<button class="icon-btn logout-btn" data-act="logout" aria-label="'+t('logout')+'" title="'+t('logout')+'">'+ic('logout','flip')+'</button></div></header>'+
  prev+'<main id="page"></main></div>'+
  '<nav class="tabs" aria-label="'+t('brand')+'">'+NAV.filter(can).map(p=>'<button data-act="nav" data-id="'+p+'"'+(S.page===p?' aria-current="page"':'')+'>'+ic(PAGE_IC[p])+'<span>'+t('nav_'+p)+'</span></button>').join('')+'</nav>';
  renderPage();renderModal();
}
function renderLogin(){
  const demo=S.data.members.map(m=>'<button type="button" class="chip" data-act="fill" data-id="'+m.id+'">'+esc(pName(m))+' <small>'+t(m.role==='manager'?'role_manager':'role_admin')+'</small></button>').join('');
  $('#app').innerHTML=
  '<section class="login-panel"><div class="seg login-lang" role="group"><button data-act="lang" data-id="ku" aria-pressed="'+(S.lang==='ku')+'">'+T.ku.lang_ku+'</button><button data-act="lang" data-id="ar" aria-pressed="'+(S.lang==='ar')+'">'+T.ku.lang_ar+'</button><button data-act="lang" data-id="en" aria-pressed="'+(S.lang==='en')+'">English</button></div>'+
  '<form class="login-card" id="form-login" novalidate><div><h1>'+t('login_title')+'</h1><p class="lead">'+t('login_sub')+'</p></div>'+
  fld('f-email',t('f_email'),inp('f-email','','type="email" dir="ltr" autocomplete="username" autocapitalize="off" spellcheck="false"'))+
  '<label class="fld" for="f-pass"><span>'+t('f_password')+'</span><div class="pw"><input id="f-pass" name="f-pass" type="password" autocomplete="current-password"><button type="button" class="pw-btn" data-act="togglepw">'+t('show')+'</button></div></label>'+
  '<p class="err" id="form-err" role="alert"></p><button class="btn pri" type="submit">'+t('sign_in')+'</button>'+
  '<div class="demo"><span class="eyebrow">'+t('demo_title')+'</span><div class="chips">'+demo+'</div></div></form></section>';
}
function renderPage(){
  const pg={dashboard:pgDashboard,shipments:pgShipments,merchants:pgMerchants,debts:pgDebts,profit:pgProfit,team:pgTeam,profile:pgProfile,received:pgReceived,sales:pgSales,expenses:pgExpenses,assets:pgAssets}[S.page];
  $('#page').innerHTML=can(S.page)?pg():noAccess();
}
function noAccess(){return '<div class="noacc">'+ic('lock')+'<h2>'+t('no_access')+'</h2><p>'+t('no_access_sub')+'</p></div>'}
function head(title,sub,actions){return '<div class="ph"><div><h1>'+title+'</h1>'+(sub?'<p>'+sub+'</p>':'')+'</div>'+(actions?'<div>'+actions+'</div>':'')+'</div>'}

/* ---------- dashboard ---------- */
function monthly(codes){
  const out=[];
  for(let i=5;i>=0;i--){const m=new Date(today.getFullYear(),today.getMonth()-i,1);out.push({key:m.getFullYear()+'-'+pad(m.getMonth()+1,2),m:m.getMonth(),v:0})}
  codes.forEach(c=>{const o=out.find(x=>x.key===c.buy.slice(0,7));if(o)o.v+=calc(c).profit});
  return out;
}
function cargoCard(w,a){
  const B=w?a.wB:a.cB,SD=w?a.wS:a.cS,cost=w?a.wCostB:a.cCostB,rev=w?a.wRev:a.cRev,u=w?t('u_kg'):t('u_cbm'),d=w?0:1,pd=w?2:0;
  const pct=B?Math.min(100,SD/B*100):0;
  return '<section class="card"><header><span class="ico">'+ic(w?'box':'ship')+'</span><h3>'+t(w?'weight_title':'sea_title')+' ('+u+')</h3></header>'+
  '<div class="pair"><div><span class="lbl">'+t('purchased')+'</span><b>'+num(fmt(B,d))+'</b><small>'+t('avg')+' '+num(usd(B?cost/B:0,pd))+'</small></div>'+
  '<div><span class="lbl">'+t('sold')+'</span><b>'+num(fmt(SD,d))+'</b><small>'+t('avg')+' '+num(usd(SD?rev/SD:0,pd))+'</small></div></div>'+
  '<div class="bar"><i style="width:'+pct+'%"></i></div><p class="left">'+t('remaining')+': '+num(fmt(B-SD,d))+' '+u+' · '+num(fmt(100-pct,0)+'%')+'</p></section>';
}
function pgDashboard(){
  const codes=S.data.codes,a=agg(codes),cnt=[0,0,0,0,0];
  codes.forEach(c=>cnt[c.status]++);
  const debt=S.data.merchants.reduce((x,m)=>x+merStats(m).balance,0);
  const months=monthly(codes),mx=niceCeil(Math.max(1,...months.map(x=>x.v)));
  const stages=cnt.map((n,i)=>'<button class="stage st'+i+'" data-act="gostatus" data-id="'+i+'"><span class="lbl">'+t('st'+i)+'</span><b>'+num(n)+'</b><div class="sbar"><i style="width:'+(n/(codes.length||1)*100)+'%"></i></div><small>'+num(fmt(n/(codes.length||1)*100,0)+'%')+' '+t('of_codes')+'</small></button>').join('');
  const chart='<div class="chart"><div class="yax">'+[1,.5,0].map(f=>'<span>'+kfmt(mx*f)+'</span>').join('')+'</div>'+
    '<div class="plot"><i class="gl" style="bottom:100%"></i><i class="gl" style="bottom:50%"></i><div class="cols">'+months.map(m=>'<div class="col"><div class="bar2" style="height:'+(m.v/mx*100)+'%"><em>'+kfmt(m.v)+'</em></div></div>').join('')+'</div></div>'+
    '<div></div><div class="mlabs">'+months.map(m=>'<span>'+MONTHS[S.lang][m.m]+'</span>').join('')+'</div></div>';
  const tm={};
  codes.forEach(c=>c.sales.forEach(s=>{const o=tm[s.merchantId]||(tm[s.merchantId]={rev:0,profit:0});const v=s.wQty*s.wPrice+s.cQty*s.cPrice;o.rev+=v;o.profit+=v-(s.wQty*c.wCost+s.cQty*c.cCost)}));
  codes.forEach(c=>{const k=calc(c);if(c.merchantId&&(k.lumpRev||k.lumpCostSold)){const o=tm[c.merchantId]||(tm[c.merchantId]={rev:0,profit:0});o.rev+=k.lumpRev;o.profit+=k.lumpRev-k.lumpCostSold}});
  const top=Object.keys(tm).map(k=>({m:mer(k),rev:tm[k].rev,profit:tm[k].profit})).sort((x,y)=>y.rev-x.rev).slice(0,5),tmax=top.length?top[0].rev:1;
  const rank='<ul>'+top.map(x=>'<li><div class="row"><span>'+esc(mName(x.m))+'</span><span>'+num(usd(x.rev))+'</span></div><div class="bar"><i style="width:'+(x.rev/tmax*100)+'%"></i></div><small>'+t('profit')+' '+num(usd(x.profit))+'</small></li>').join('')+'</ul>';
  const recent=codes.slice().sort((x,y)=>y.buy.localeCompare(x.buy)||y.id.localeCompare(x.id)).slice(0,6);
  const rows=recent.map(c=>{const k=calc(c);return '<tr data-act="open-code" data-id="'+c.id+'" tabindex="0"><td class="mainc cell-main"><span class="mono"><b>'+c.id+'</b></span><small>'+esc(mName(mer(c.merchantId)))+' · '+esc(goodsName(c))+'</small></td><td data-l="'+t('col_mode')+'">'+modeTag(c.mode)+'</td><td data-l="'+t('col_status')+'">'+stPill(c.status)+'</td><td class="end" data-l="'+t('col_profit')+'"><b class="'+profitCls(k.profit)+'">'+num(usd(k.profit))+'</b></td></tr>'}).join('');
  return '<div class="ph"><div><h1>'+t('dash_title')+'</h1><p>'+t('dash_sub')+' · '+t('viewed')+' '+num(stamp())+'</p></div></div>'+
  '<section class="hero"><span class="eyebrow">'+t('hero_eyebrow')+' · '+t('hero_modes')+'</span><div class="route"><span>'+t('china')+'</span>'+ic('chev','flip')+'<span>'+t('iraq')+'</span>'+ic('chev','flip')+'<span>'+t('kurdistan')+'</span></div></section>'+
  '<h2 class="eyebrow" style="margin:0 0 8px">'+t('pipe_title')+'</h2><div class="pipe">'+stages+'</div>'+
  '<div class="kpis">'+cargoCard(true,a)+cargoCard(false,a)+
  '<section class="card profit"><header><span class="ico">'+ic('chart')+'</span><h3>'+t('profit')+'</h3></header><div class="big">'+num(usd(a.profit))+'</div><p style="color:#E4DBF5;margin-top:4px">'+t('margin')+' '+num(fmt(a.rev?a.profit/a.rev*100:0,1)+'%')+'</p>'+
  '<div class="mini"><div>'+t('revenue')+'<b>'+num(usd(a.rev))+'</b></div><div>'+t('cost_sold')+'<b>'+num(usd(a.costSold))+'</b></div><div>'+t('outstanding')+'<b>'+num(usd(debt))+'</b></div><div>'+t('nav_merchants')+' · '+t('codes_n')+'<b>'+num(S.data.merchants.length+' · '+codes.length)+'</b></div></div></section></div>'+
  '<div class="split"><section class="card"><header><div><h3>'+t('chart_title')+'</h3><p class="hint">'+t('chart_sub')+'</p></div></header>'+chart+'</section>'+
  '<section class="card rank"><header><div><h3>'+t('top_title')+'</h3><p class="hint">'+t('top_sub')+'</p></div></header>'+rank+'</section></div>'+
  '<h2 class="eyebrow" style="margin:6px 0 8px">'+t('recent_title')+'</h2><div class="tbl-card cards"><div class="tbl-scroll"><table class="tbl"><thead><tr><th>'+t('col_code')+'</th><th>'+t('col_mode')+'</th><th>'+t('col_status')+'</th><th class="end">'+t('col_profit')+'</th></tr></thead><tbody>'+rows+'</tbody></table></div></div>';
}

/* ---------- shipments ---------- */
function filteredCodes(){
  const q=S.f.q.trim().toLowerCase();
  return S.data.codes.filter(c=>{
    if(S.f.status!=='all'&&c.status!==+S.f.status)return false;
    if(S.f.mode!=='all'&&c.mode!==S.f.mode)return false;
    if(!q)return true;
    const hay=[c.id,c.track,(mer(c.merchantId)?mer(c.merchantId).en+' '+mer(c.merchantId).ku+' '+mer(c.merchantId).code:''),GOODS[c.goods].join(' '),ORIGINS[c.origin].join(' '),c.sales.map(s=>{const m=mer(s.merchantId);return m?m.en+' '+m.ku:''}).join(' ')].join(' ').toLowerCase();
    return hay.includes(q);
  }).sort((a,b)=>b.buy.localeCompare(a.buy)||b.id.localeCompare(a.id));
}
function codeTable(){
  const list=filteredCodes();
  if(!list.length)return '<div class="tbl-card"><div class="empty">'+t('no_results')+'</div></div>';
  const rows=list.map(c=>{const k=calc(c);return '<tr data-act="open-code" data-id="'+c.id+'" tabindex="0">'+
    '<td class="mainc cell-main"><span class="mono"><b>'+c.id+'</b></span><small>'+esc(mName(mer(c.merchantId)))+'</small><small>'+num(c.buy)+(c.track?' · <span class="mono">'+esc(c.track)+'</span>':'')+'</small></td>'+
    '<td data-l="'+t('col_goods')+'" class="cell-main"><b>'+esc(goodsName(c))+'</b><small>'+esc(pickL(ORIGINS[c.origin]))+'</small></td>'+
    '<td data-l="'+t('col_mode')+'">'+modeTag(c.mode)+'</td>'+
    '<td data-l="'+t('col_weight')+'">'+qtyCell(k.wSold,c.wQty,t('u_kg'),0)+'</td>'+
    '<td data-l="'+t('col_sea')+'">'+qtyCell(k.cSold,c.cQty,t('u_cbm'),1)+'</td>'+
    '<td data-l="'+t('col_profit')+'" class="end"><b class="'+profitCls(k.profit)+'">'+num(usd(k.profit))+'</b></td>'+
    '<td data-l="'+t('col_status')+'">'+stPill(c.status)+'</td></tr>'}).join('');
  return '<div class="tbl-card cards"><div class="tbl-scroll"><table class="tbl"><thead><tr><th>'+t('col_code')+'</th><th>'+t('col_goods')+'</th><th>'+t('col_mode')+'</th><th>'+t('col_weight')+' · '+t('sold')+' / '+t('purchased')+'</th><th>'+t('col_sea')+' · '+t('sold')+' / '+t('purchased')+'</th><th class="end">'+t('col_profit')+'</th><th>'+t('col_status')+'</th></tr></thead><tbody>'+rows+'</tbody></table></div></div>';
}
function pgShipments(){
  const cnt=[0,0,0,0,0];S.data.codes.forEach(c=>cnt[c.status]++);
  const chip=(id,label,n)=>'<button class="chip" data-act="fstatus" data-id="'+id+'" aria-pressed="'+(String(S.f.status)===String(id))+'">'+label+(n!=null?' <small>'+num(n)+'</small>':'')+'</button>';
  return subnav('shipments')+head(t('ship_title'),t('ship_sub'),'<button class="btn pri" data-act="new-code">'+ic('plus')+t('new_code')+'</button>')+
  '<div class="toolbar"><label class="search" for="q">'+ic('search')+'<input id="q" type="search" value="'+esc(S.f.q)+'" placeholder="'+t('search_ph')+'" autocomplete="off"></label>'+
  '<select id="flt-mode" aria-label="'+t('f_mode')+'"><option value="all">'+t('f_mode_all')+'</option>'+['sea','air','land'].map(m=>'<option value="'+m+'"'+(S.f.mode===m?' selected':'')+'>'+t('mode_'+m)+'</option>').join('')+'</select></div>'+
  '<div class="chips">'+chip('all',t('f_all'),S.data.codes.length)+cnt.map((n,i)=>chip(i,t('st'+i),n)).join('')+'</div>'+
  '<div id="code-list">'+codeTable()+'</div>';
}

/* ---------- code detail ---------- */
function sheet(title,body,opts){
  opts=opts||{};
  return '<div class="modal-back"><section class="sheet'+(opts.narrow?' narrow':'')+'" role="dialog" aria-modal="true" aria-label="'+esc(opts.label||'')+'"><header class="sheet-h"><div>'+title+'</div><button class="icon-btn" data-act="close" aria-label="'+t('close')+'">'+ic('x')+'</button></header>'+body+'</section></div>';
}
function codeSheet(c){
  const k=calc(c);
  const steps=[0,1,2,3,4].map(i=>'<li class="'+(i<c.status?'done':i===c.status?'done now':'')+'"><span class="dot">'+(i<=c.status?ic('check'):i+1)+'</span><span>'+t('st'+i+'_full')+'</span><span class="dt">'+(c.dates[i]?num(c.dates[i]):'—')+'</span></li>').join('');
  const nextBtn=c.status<4?'<button class="btn pri sm" data-act="advance" data-id="'+c.id+'">'+t('advance',{s:t('st'+(c.status+1))})+'</button>':'<span class="hint">'+t('all_done')+'</span>';
  const undo=c.status>0?'<button class="btn sm" data-act="undo" data-id="'+c.id+'">'+t('undo')+'</button>':'';
  const wu=t('u_kg'),cu=t('u_cbm');
  const row=(label,q,d,unit,price,total,cls)=>'<tr class="'+(cls||'')+'"><td>'+label+'</td><td class="end">'+(q?num(fmt(q,d))+' '+unit:'—')+'</td><td class="end">'+(q?num(usd(price,price%1?2:0)):'—')+'</td><td class="end">'+(q?num(usd(total)):'—')+'</td></tr>';
  const cargo='<div class="tbl-scroll"><table class="cg"><thead><tr><th>'+t('c_item')+'</th><th class="end">'+t('c_qty')+'</th><th class="end">'+t('c_unit')+'</th><th class="end">'+t('c_total')+'</th></tr></thead><tbody>'+
    '<tr class="grp"><td colspan="4">'+t('weight_title')+' ('+wu+')</td></tr>'+
    row(t('weight_purchased'),c.wQty,0,wu,c.wCost,c.wQty*c.wCost)+row(t('weight_sold'),k.wSold,0,wu,k.wAvg,k.wRev,'soldrow')+
    '<tr><td class="hint">'+t('left_unsold')+'</td><td class="end hint">'+(c.wQty?num(fmt(k.wLeft,0))+' '+wu:'—')+'</td><td></td><td></td></tr>'+
    '<tr class="grp"><td colspan="4">'+t('sea_title')+' ('+cu+')</td></tr>'+
    row(t('sea_purchased'),c.cQty,1,cu,c.cCost,c.cQty*c.cCost)+row(t('sea_sold'),k.cSold,1,cu,k.cAvg,k.cRev,'soldrow')+
    '<tr><td class="hint">'+t('left_unsold')+'</td><td class="end hint">'+(c.cQty?num(fmt(k.cLeft,1))+' '+cu:'—')+'</td><td></td><td></td></tr></tbody></table></div>';
  const stats='<div class="stats"><div class="stat"><span>'+t('revenue')+'</span><b>'+num(usd(k.rev))+'</b></div><div class="stat"><span>'+t('cost_sold')+'</span><b>'+num(usd(k.costSold))+'</b></div><div class="stat"><span>'+t('profit')+'</span><b class="'+profitCls(k.profit)+'">'+num(usd(k.profit))+'</b></div><div class="stat"><span>'+t('margin')+'</span><b>'+num(fmt(k.margin*100,1)+'%')+'</b></div></div><p class="note">'+t('profit_note')+'</p>';
  const sales=c.sales.length?'<div class="tbl-scroll"><table class="cg"><thead><tr><th>'+t('col_merchant')+'</th><th class="end">'+t('col_weight')+'</th><th class="end">'+t('col_sea')+'</th><th class="end">'+t('c_total')+'</th><th class="end">'+t('profit')+'</th><th></th></tr></thead><tbody>'+
    c.sales.map(s=>{const v=s.wQty*s.wPrice+s.cQty*s.cPrice,p=v-(s.wQty*c.wCost+s.cQty*c.cCost);return '<tr><td><b>'+esc(mName(mer(s.merchantId)))+'</b><span class="sub2">'+num(s.date)+'</span></td>'+
      '<td class="end">'+(s.wQty?num(fmt(s.wQty))+'<span class="sub2">'+num('@ '+usd(s.wPrice,2))+'</span>':'—')+'</td>'+
      '<td class="end">'+(s.cQty?num(fmt(s.cQty,1))+'<span class="sub2">'+num('@ '+usd(s.cPrice))+'</span>':'—')+'</td>'+
      '<td class="end">'+num(usd(v))+'</td><td class="end"><b class="'+profitCls(p)+'">'+num(usd(p))+'</b></td>'+
      '<td class="end"><button class="del-x" data-act="del-sale" data-id="'+c.id+'|'+s.id+'" aria-label="'+t('remove')+'">'+ic('x')+'</button></td></tr>'}).join('')+'</tbody></table></div>':'<p class="hint">'+t('no_sales')+'</p>';
  const body='<div class="sec"><div class="meta">'+
    '<div><span>'+t('f_merchant')+'</span><b>'+esc(mName(mer(c.merchantId)))+'</b> <span class="mono">'+(mer(c.merchantId)?mer(c.merchantId).code:'')+'</span></div>'+
    '<div><span>'+t('d_track')+'</span><b class="mono">'+(c.track?esc(c.track):'—')+'</b>'+(c.track?'<button class="copy" data-act="copy" data-text="'+esc(c.track)+'" aria-label="'+t('copy')+'">'+ic('copy')+'</button>':'')+'</div>'+
    '<div><span>'+t('d_route')+'</span><b>'+esc(pickL(ORIGINS[c.origin]))+'</b> '+ic('chev','flip')+' <b>'+esc(pickL(CITIES[c.dest]))+'</b></div>'+
    '<div><span>'+t('d_goods')+'</span><b>'+esc(goodsName(c))+'</b></div>'+
    '<div><span>'+t('d_buy')+'</span><b>'+num(c.buy)+'</b></div>'+(c.tCost?'<div><span>'+t('d_tcost')+'</span><b>'+num(usd(c.tCost))+'</b></div>':'')+(c.tSale?'<div><span>'+t('d_tsale')+'</span><b>'+num(usd(c.tSale))+'</b></div>':'')+(c.notes?'<div><span>'+t('d_notes')+'</span><b>'+esc(c.notes)+'</b></div>':'')+'</div></div>'+
    '<div class="sec"><h3>'+t('timeline')+'</h3><ol class="tl">'+steps+'</ol><div class="tl-actions">'+nextBtn+undo+'</div></div>'+
    '<div class="sec"><h3>'+t('cargo_title')+'</h3>'+cargo+'</div>'+
    '<div class="sec"><h3>'+t('profit_title')+'</h3>'+stats+'</div>'+
    '<div class="sec"><h3><span>'+t('sales_title')+'</span><button class="btn sm pri" data-act="new-sale" data-id="'+c.id+'">'+ic('plus')+t('add_sale')+'</button></h3>'+sales+'</div>'+
    '<div class="sheet-f"><div class="grp"><button class="btn" data-act="edit-code" data-id="'+c.id+'">'+t('edit')+'</button></div><div class="grp"><button class="btn danger" data-act="del-code" data-id="'+c.id+'" data-confirm="'+t('confirm_del')+'">'+t('del_code')+'</button></div></div>';
  return sheet('<span class="eyebrow">'+t('col_code')+'</span><h2><span class="mono">'+c.id+'</span></h2><div class="pills">'+stPill(c.status)+modeTag(c.mode)+'</div>',body,{label:c.id});
}

/* ---------- forms ---------- */
function codeForm(c){
  const isNew=!c;
  const d=c||{id:'',merchantId:'',track:'',mode:'sea',goods:'clothes',origin:'yiwu',dest:'erbil',buy:iso(today),wQty:'',wCost:'',cQty:'',cCost:'',notes:''};
  const body='<form id="form-code" data-id="'+(isNew?'':c.id)+'" novalidate><div class="sec grid2">'+
    fld('mp-q',t('f_merchant'),merPicker(mer(d.merchantId)),'full')+
    '<div class="fld full"><span>'+t('code_preview')+'</span><b class="mono" id="code-prev" style="font-size:20px">'+(isNew?'—':esc(d.id))+'</b></div>'+fld('f-track',t('f_track'),inp('f-track',d.track,'autocomplete="off" dir="ltr"'),'full')+
    fld('f-mode',t('f_mode'),sel('f-mode',['sea','air','land'].map(m=>[m,t('mode_'+m)]),d.mode))+fld('f-goods',t('f_goods'),sel('f-goods',Object.keys(GOODS).map(k=>[k,pickL(GOODS[k])]),d.goods))+
    fld('f-origin',t('f_origin'),sel('f-origin',Object.keys(ORIGINS).map(k=>[k,pickL(ORIGINS[k])]),d.origin))+fld('f-dest',t('f_dest'),sel('f-dest',DESTS.map(k=>[k,pickL(CITIES[k])]),d.dest))+
    fld('f-buy',t('f_buy'),inp('f-buy',d.buy,'type="date"'))+'<span></span>'+
    fld('f-wp',t('f_wp'),inp('f-wp',d.wCost,'type="number" min="0" step="any" inputmode="decimal"'))+fld('f-cp',t('f_cp'),inp('f-cp',d.cCost,'type="number" min="0" step="any" inputmode="decimal"'))+
    fld('f-tcost',t('f_tcost'),inp('f-tcost',d.tCost||'','type="number" min="0" step="any" inputmode="decimal"'))+fld('f-tsale',t('f_tsale'),inp('f-tsale',d.tSale||'','type="number" min="0" step="any" inputmode="decimal"'))+
    fld('f-notes',t('f_notes'),'<textarea id="f-notes" name="f-notes">'+esc(d.notes)+'</textarea>','full')+
    '<p class="err full" id="form-err" role="alert"></p></div><div class="sheet-f"><span></span><div class="grp"><button type="button" class="btn" data-act="close">'+t('cancel')+'</button><button type="submit" class="btn pri">'+t('save')+'</button></div></div></form>';
  return sheet('<h2>'+t(isNew?'form_new_code':'form_edit_code')+'</h2>',body,{narrow:true,label:t(isNew?'form_new_code':'form_edit_code')});
}
function saleHints(){
  const a=stockTotals();return {w:t('avail')+': '+num(fmt(a.wL,0))+' '+t('u_kg'),c:t('avail')+': '+num(fmt(a.cL,1))+' '+t('u_cbm')};
}
function saleForm(c0){
  const glob=!c0,c=c0||null,h=saleHints();
  const codeSel=glob?fld('f-scode',t('f_sale_code'),sel('f-scode',[['',t('pick_code')]].concat(S.data.codes.slice().sort((a,b)=>b.buy.localeCompare(a.buy)||b.id.localeCompare(a.id)).map(x=>[x.id,x.id+' · '+mName(mer(x.merchantId))+' · '+goodsName(x)])),''),'full'):'';
  const body='<form id="form-sale" data-id="'+(c?c.id:'')+'" novalidate><div class="sec grid2">'+codeSel+
    fld('f-merchant',t('sale_to'),sel('f-merchant',[['',t('pick_merchant')]].concat(S.data.merchants.slice().sort((a,b)=>mName(a).localeCompare(mName(b))).map(m=>[m.id,m.code+' · '+mName(m)])),c?c.merchantId||'':''),'full')+
    fld('f-swq',t('s_w_qty'),inp('f-swq','','type="number" min="0" step="any" inputmode="decimal"')+'<span class="hint" id="hint-w">'+h.w+'</span>')+
    fld('f-swp',t('s_w_price'),inp('f-swp',c&&c.wCost?+(c.wCost*1.2).toFixed(2):'','type="number" min="0" step="any" inputmode="decimal"'))+
    fld('f-scq',t('s_c_qty'),inp('f-scq','','type="number" min="0" step="any" inputmode="decimal"')+'<span class="hint" id="hint-c">'+h.c+'</span>')+
    fld('f-scp',t('s_c_price'),inp('f-scp',c&&c.cCost?Math.round(c.cCost*1.2):'','type="number" min="0" step="any" inputmode="decimal"'))+
    '<p class="err full" id="form-err" role="alert"></p></div><div class="sheet-f"><span></span><div class="grp"><button type="button" class="btn" data-act="close">'+t('cancel')+'</button><button type="submit" class="btn pri">'+t('save')+'</button></div></div></form>';
  return sheet('<span class="eyebrow">'+t('sales_title')+'</span><h2>'+(c?t('sale_title',{c:c.id}):t('new_sale'))+'</h2>',body,{narrow:true,label:t('add_sale')});
}
function receiptForm(){
  const body='<form id="form-receipt" novalidate><div class="sec grid2">'+
    fld('f-rdate',t('f_date'),inp('f-rdate',iso(today),'type="date"'),'full')+
    fld('f-rw',t('f_rcv_w'),inp('f-rw','','type="number" min="0" step="any" inputmode="decimal"'))+
    fld('f-rc',t('f_rcv_c'),inp('f-rc','','type="number" min="0" step="any" inputmode="decimal"'))+
    fld('f-rnote',t('f_notes'),inp('f-rnote','','autocomplete="off"'),'full')+
    '<p class="err full" id="form-err" role="alert"></p></div><div class="sheet-f"><span></span><div class="grp"><button type="button" class="btn" data-act="close">'+t('cancel')+'</button><button type="submit" class="btn pri">'+t('save')+'</button></div></div></form>';
  return sheet('<span class="eyebrow">'+t('nav_received')+'</span><h2>'+t('rcv_form_title')+'</h2>',body,{narrow:true,label:t('new_receipt')});
}
function merchantForm(m){
  const isNew=!m,d=m||{code:nextMerCode(),ku:'',en:'',phone:'',city:'erbil',notes:''};
  const body='<form id="form-merchant" data-id="'+(isNew?'':m.id)+'" novalidate><div class="sec grid2">'+
    fld('f-name-ku',t('f_name_ku'),inp('f-name-ku',d.ku,'autocomplete="off" dir="rtl"'))+fld('f-name-en',t('f_name_en'),inp('f-name-en',d.en,'autocomplete="off" dir="ltr"'))+
    fld('f-mcode',t('m_code'),inp('f-mcode',d.code,'type="number" min="1" step="1" inputmode="numeric" dir="ltr"'))+fld('f-city',t('f_city'),sel('f-city',Object.keys(CITIES).map(k=>[k,pickL(CITIES[k])]),d.city))+
    fld('f-phone',t('f_phone'),inp('f-phone',d.phone,'type="tel" dir="ltr" inputmode="tel"'),'full')+
    fld('f-notes',t('f_notes'),'<textarea id="f-notes" name="f-notes">'+esc(d.notes)+'</textarea>','full')+
    '<p class="err full" id="form-err" role="alert"></p></div><div class="sheet-f"><span></span><div class="grp"><button type="button" class="btn" data-act="close">'+t('cancel')+'</button><button type="submit" class="btn pri">'+t('save')+'</button></div></div></form>';
  return sheet('<h2>'+t(isNew?'form_new_merchant':'form_edit_merchant')+'</h2>',body,{narrow:true,label:t('form_new_merchant')});
}
function memberForm(){
  const body='<form id="form-member" novalidate><div class="sec grid2">'+
    fld('f-mname',t('f_member_name'),inp('f-mname','','autocomplete="off"'))+fld('f-memail',t('f_email'),inp('f-memail','','type="email" dir="ltr" autocomplete="off"'))+fld('f-mpw',t('f_mpw'),inp('f-mpw','','type="password" autocomplete="new-password"'),'full')+fld('f-msalary',t('f_salary'),inp('f-msalary','','type="number" min="0" step="any" inputmode="decimal"'),'full')+
    '<div class="fld full"><span>'+t('access_label')+'</span>'+SECTIONS.map(s=>'<div class="perm"><span>'+t('perm_'+s)+'</span><label class="switch"><input type="checkbox" name="perm" value="'+s+'"><span class="track"></span></label></div>').join('')+'</div>'+
    '<p class="err full" id="form-err" role="alert"></p></div><div class="sheet-f"><span></span><div class="grp"><button type="button" class="btn" data-act="close">'+t('cancel')+'</button><button type="submit" class="btn pri">'+t('save')+'</button></div></div></form>';
  return sheet('<span class="eyebrow">'+t('role_admin')+'</span><h2>'+t('form_new_member')+'</h2>',body,{narrow:true,label:t('form_new_member')});
}

/* ---------- merchants ---------- */
function merStats(m){
  let codes=new Set(),bought=0,profit=0,paid=0,last='';
  S.data.codes.forEach(c=>{if(c.merchantId===m.id){codes.add(c.id);const q=calc(c);bought+=q.lumpRev;profit+=q.lumpRev-q.lumpCostSold}c.sales.forEach(s=>{if(s.merchantId===m.id){codes.add(c.id);const v=s.wQty*s.wPrice+s.cQty*s.cPrice;bought+=v;profit+=v-(s.wQty*c.wCost+s.cQty*c.cCost)}})});
  S.data.payments.forEach(p=>{if(p.merchantId===m.id){paid+=p.amount;if(p.date>last)last=p.date}});
  return {codes:codes.size,bought,profit,paid,balance:bought-paid,last};
}
function merTable(){
  const q=S.f.mq.trim().toLowerCase();
  const list=S.data.merchants.filter(m=>!q||(m.en+' '+m.ku+' '+m.phone+' '+m.code).toLowerCase().includes(q)).sort((a,b)=>mName(a).localeCompare(mName(b)));
  if(!list.length)return '<div class="tbl-card"><div class="empty">'+t('no_results')+'</div></div>';
  const rows=list.map(m=>{const k=merStats(m);return '<tr data-act="open-merchant" data-id="'+m.id+'" tabindex="0"><td class="mainc cell-main"><b>'+esc(mName(m))+'</b><small>'+t('m_code')+' <span class="mono">'+m.code+'</span></small></td>'+
    '<td data-l="'+t('col_phone')+'"><span class="mono">'+esc(m.phone)+'</span></td><td data-l="'+t('col_city')+'">'+esc(pickL(CITIES[m.city]||['—','—']))+'</td>'+
    '<td data-l="'+t('col_codes')+'" class="end">'+num(k.codes)+'</td><td data-l="'+t('col_bought')+'" class="end">'+num(usd(k.bought))+'</td><td data-l="'+t('col_balance')+'" class="end"><b class="'+(k.balance>0.5?'neg':'')+'">'+num(usd(k.balance))+'</b></td><td data-l="'+t('col_profit')+'" class="end"><b class="'+profitCls(k.profit)+'">'+num(usd(k.profit))+'</b></td></tr>'}).join('');
  return '<div class="tbl-card cards"><div class="tbl-scroll"><table class="tbl"><thead><tr><th>'+t('col_name')+'</th><th>'+t('col_phone')+'</th><th>'+t('col_city')+'</th><th class="end">'+t('col_codes')+'</th><th class="end">'+t('col_bought')+'</th><th class="end">'+t('col_balance')+'</th><th class="end">'+t('col_profit')+'</th></tr></thead><tbody>'+rows+'</tbody></table></div></div>';
}
function pgMerchants(){
  return head(t('mer_title'),t('mer_sub'),'<button class="btn pri" data-act="new-merchant">'+ic('plus')+t('new_merchant')+'</button>')+
  '<div class="toolbar"><label class="search" for="mq">'+ic('search')+'<input id="mq" type="search" value="'+esc(S.f.mq)+'" placeholder="'+t('mer_search')+'" autocomplete="off"></label></div><div id="mer-list">'+merTable()+'</div>';
}
function merSheet(m){
  const k=merStats(m),items=[];
  S.data.codes.forEach(c=>c.sales.forEach(s=>{if(s.merchantId===m.id)items.push({c,s})}));
  items.sort((a,b)=>b.s.date.localeCompare(a.s.date));
  const pls=S.data.payments.filter(p=>p.merchantId===m.id).sort((a,b)=>b.date.localeCompare(a.date)||b.id.localeCompare(a.id));
  const pays=pls.length?'<div class="tbl-scroll"><table class="cg"><thead><tr><th>'+t('f_date')+'</th><th class="end">'+t('col_paid')+'</th><th>'+t('f_notes')+'</th><th></th></tr></thead><tbody>'+pls.map(p=>'<tr><td>'+num(p.date)+'</td><td class="end"><b class="pos">'+num(usd(p.amount))+'</b></td><td>'+esc(p.note||'—')+'</td><td class="end"><button class="del-x" data-act="del-payment" data-id="'+p.id+'" aria-label="'+t('remove')+'">'+ic('x')+'</button></td></tr>').join('')+'</tbody></table></div>':'<p class="hint">'+t('no_payments')+'</p>';
  const mine=S.data.codes.filter(c=>c.merchantId===m.id||c.sales.some(s=>s.merchantId===m.id)).sort((x,y)=>y.buy.localeCompare(x.buy));
  const list=mine.length?'<div class="tbl-scroll"><table class="cg"><thead><tr><th>'+t('col_code')+'</th><th class="end">'+t('col_weight')+'</th><th class="end">'+t('col_sea')+'</th><th class="end">'+t('c_total')+'</th><th>'+t('col_status')+'</th></tr></thead><tbody>'+mine.map(c=>{let w=0,q=0,v=0;c.sales.filter(x=>x.merchantId===m.id).forEach(x=>{w+=x.wQty;q+=x.cQty;v+=x.wQty*x.wPrice+x.cQty*x.cPrice});return '<tr><td><a href="#" class="mono" data-act="open-code" data-id="'+c.id+'"><b>'+c.id+'</b></a><span class="sub2 mono">'+esc(c.track)+'</span></td><td class="end">'+(w?num(fmt(w)):'—')+'</td><td class="end">'+(q?num(fmt(q,1)):'—')+'</td><td class="end">'+(v?num(usd(v)):'—')+'</td><td>'+stPill(c.status)+'</td></tr>'}).join('')+'</tbody></table></div>':'<p class="hint">'+t('no_purchases')+'</p>';
  const body='<div class="sec"><div class="meta"><div><span>'+t('m_code')+'</span><b class="mono">'+m.code+'</b></div><div><span>'+t('f_phone')+'</span><b class="mono">'+esc(m.phone||'—')+'</b></div><div><span>'+t('f_city')+'</span><b>'+esc(pickL(CITIES[m.city]||['—','—']))+'</b></div>'+(m.notes?'<div><span>'+t('d_notes')+'</span><b>'+esc(m.notes)+'</b></div>':'')+'</div></div>'+
    '<div class="sec"><div class="stats"><div class="stat"><span>'+t('col_codes')+'</span><b>'+num(k.codes)+'</b></div><div class="stat"><span>'+t('col_bought')+'</span><b>'+num(usd(k.bought))+'</b></div><div class="stat"><span>'+t('col_paid')+'</span><b class="pos">'+num(usd(k.paid))+'</b></div><div class="stat"><span>'+t('col_balance')+'</span><b class="'+(k.balance>0.5?'neg':k.balance<-0.5?'pos':'')+'">'+num(usd(k.balance))+'</b></div><div class="stat"><span>'+t('profit')+'</span><b class="'+profitCls(k.profit)+'">'+num(usd(k.profit))+'</b></div></div></div>'+
    '<div class="sec"><h3><span>'+t('payments_title')+'</span><button class="btn sm pri" data-act="new-payment" data-id="'+m.id+'">'+ic('plus')+t('add_payment')+'</button></h3>'+pays+'</div>'+
    '<div class="sec"><h3>'+t('m_purchases')+'</h3>'+list+'</div><div class="sheet-f"><div class="grp"><button class="btn" data-act="mer-report" data-id="'+m.id+'">'+ic('dl')+t('mer_report')+'</button><button class="btn" data-act="edit-merchant" data-id="'+m.id+'">'+t('edit')+'</button></div></div>';
  return sheet('<span class="eyebrow">'+t('nav_merchants')+'</span><h2>'+esc(mName(m))+'</h2>',body,{label:mName(m)});
}

/* ---------- profit report (paper) ---------- */
function inPeriod(c){return periodTest(c.buy)}
function periodTest(b){
  const p=S.f.period;
  if(p==='month')return b.slice(0,7)===iso(today).slice(0,7);
  if(p==='90')return b>=iso(addDays(today,-90));
  if(p==='year')return b.slice(0,4)===String(today.getFullYear());
  if(p==='custom')return (!S.f.from||b>=S.f.from)&&(!S.f.to||b<=S.f.to);
  return true;
}
function pgProfit(){
  if(S.f.repMer&&mer(S.f.repMer))return pgMerReport(mer(S.f.repMer));
  S.f.repMer='';
  const codes=S.data.codes.filter(inPeriod).sort((a,b)=>b.id.localeCompare(a.id)),a=agg(codes);
  const dash='—',pc=(q,d)=>q?'<b>'+num(fmt(q,d))+'</b>':dash;
  const rows=codes.map(c=>{const k=calc(c);return '<tr><td><b class="mono">'+c.id+'</b><small>'+esc(mName(mer(c.merchantId)))+' · '+esc(goodsName(c))+'</small></td>'+
    '<td class="r">'+(c.wQty?num(fmt(c.wQty))+'<small>'+num(usd(c.wCost,2))+'</small>':dash)+'</td>'+
    '<td class="r">'+(k.wSold?num(fmt(k.wSold))+'<small>'+num(usd(k.wAvg,2))+'</small>':dash)+'</td>'+
    '<td class="r">'+(c.cQty?num(fmt(c.cQty,1))+'<small>'+num(usd(c.cCost))+'</small>':dash)+'</td>'+
    '<td class="r">'+(k.cSold?num(fmt(k.cSold,1))+'<small>'+num(usd(k.cAvg))+'</small>':dash)+'</td>'+
    '<td class="r">'+num(usd(k.rev))+'</td><td class="r"><b class="'+profitCls(k.profit)+'">'+num(usd(k.profit))+'</b></td></tr>'}).join('');
  const tm={};
  codes.forEach(c=>c.sales.forEach(s=>{const o=tm[s.merchantId]||(tm[s.merchantId]={codes:new Set(),w:0,c:0,rev:0,profit:0});o.codes.add(c.id);o.w+=s.wQty;o.c+=s.cQty;const v=s.wQty*s.wPrice+s.cQty*s.cPrice;o.rev+=v;o.profit+=v-(s.wQty*c.wCost+s.cQty*c.cCost)}));
  codes.forEach(c=>{const k=calc(c);if(c.merchantId&&(k.lumpRev||k.lumpCostSold)){const o=tm[c.merchantId]||(tm[c.merchantId]={codes:new Set(),w:0,c:0,rev:0,profit:0});o.codes.add(c.id);o.rev+=k.lumpRev;o.profit+=k.lumpRev-k.lumpCostSold}});
  const mrows=Object.keys(tm).map(k=>({m:mer(k),o:tm[k]})).sort((x,y)=>y.o.profit-x.o.profit).map(x=>'<tr><td><b>'+esc(mName(x.m))+'</b></td><td class="r">'+num(x.o.codes.size)+'</td><td class="r">'+(x.o.w?num(fmt(x.o.w)):dash)+'</td><td class="r">'+(x.o.c?num(fmt(x.o.c,1)):dash)+'</td><td class="r">'+num(usd(x.o.rev))+'</td><td class="r"><b class="'+profitCls(x.o.profit)+'">'+num(usd(x.o.profit))+'</b></td></tr>').join('');
  const periodLabel=periodText();
  return finNav('profit')+head(t('pr_title'),t('pr_sub'))+
  prBar()+
  '<article class="paper" aria-label="'+t('pr_title')+'"><header class="paper-h"><span class="logo" role="img" aria-label="'+t('brand')+'"></span><div><h2>'+bi('pr_title')+'</h2>'+
  '<div class="paper-meta"><span>'+t('viewed')+'</span><b>'+num(stamp())+'</b><span>'+t('period')+'</span><b>'+periodLabel+'</b><span>'+t('prepared_by')+'</span><b>'+esc(pName(me()))+'</b></div></div></header>'+
  '<div class="paper-sum"><div><span>'+t('revenue')+'</span><b>'+num(usd(a.rev))+'</b></div><div><span>'+t('cost_sold')+'</span><b>'+num(usd(a.costSold))+'</b></div><div><span>'+t('profit')+'</span><b class="'+profitCls(a.profit)+'">'+num(usd(a.profit))+'</b></div><div><span>'+t('margin')+'</span><b>'+num(fmt(a.rev?a.profit/a.rev*100:0,1)+'%')+'</b></div></div>'+
  '<h3>'+t('by_code')+'</h3><div class="pscroll"><table class="ptbl"><thead><tr><th>'+t('col_code')+'</th><th class="r">'+t('weight_purchased')+'<small>'+t('u_kg')+' · $</small></th><th class="r">'+t('weight_sold')+'<small>'+t('u_kg')+' · $</small></th><th class="r">'+t('sea_purchased')+'<small>CBM · $</small></th><th class="r">'+t('sea_sold')+'<small>CBM · $</small></th><th class="r">'+t('revenue')+'</th><th class="r">'+t('profit')+'</th></tr></thead><tbody>'+rows+'</tbody>'+
  '<tfoot><tr><td>'+t('totals')+' · '+num(codes.length)+' '+t('codes_n')+'</td><td class="r">'+num(fmt(a.wB))+'</td><td class="r">'+num(fmt(a.wS))+'</td><td class="r">'+num(fmt(a.cB,1))+'</td><td class="r">'+num(fmt(a.cS,1))+'</td><td class="r">'+num(usd(a.rev))+'</td><td class="r">'+num(usd(a.profit))+'</td></tr></tfoot></table></div>'+
  '<h3>'+t('by_merchant')+'</h3><div class="pscroll"><table class="ptbl"><thead><tr><th>'+t('col_name')+'</th><th class="r">'+t('col_codes')+'</th><th class="r">'+t('col_weight')+'</th><th class="r">'+t('col_sea')+'</th><th class="r">'+t('revenue')+'</th><th class="r">'+t('profit')+'</th></tr></thead><tbody>'+mrows+'</tbody></table></div>'+
  '<footer class="paper-foot"><span>'+t('foot_note')+'</span><span>'+t('brand')+' · '+num(stamp())+'</span></footer></article>';
}



function prBar(){
  return '<div class="pr-bar"><label class="fld" for="f-period" style="grid-auto-flow:column;align-items:center;gap:10px"><span>'+t('period')+'</span><select id="f-period">'+[['all','p_all'],['month','p_month'],['90','p_90'],['year','p_year'],['custom','p_custom']].map(o=>'<option value="'+o[0]+'"'+(S.f.period===o[0]?' selected':'')+'>'+t(o[1])+'</option>').join('')+'</select></label>'+
  (S.f.period==='custom'?'<label class="fld" for="f-from" style="grid-auto-flow:column;align-items:center;gap:8px"><span>'+t('d_from')+'</span><input type="date" id="f-from" value="'+S.f.from+'" max="'+S.f.to+'"></label><label class="fld" for="f-to" style="grid-auto-flow:column;align-items:center;gap:8px"><span>'+t('d_to')+'</span><input type="date" id="f-to" value="'+S.f.to+'" min="'+S.f.from+'"></label>':'')+
  '<label class="fld" for="f-repmer" style="grid-auto-flow:column;align-items:center;gap:8px"><span>'+t('rep_mer')+'</span><select id="f-repmer"><option value="">'+t('rep_all')+'</option>'+S.data.merchants.slice().sort((a,b)=>a.code-b.code).map(m=>'<option value="'+m.id+'"'+(S.f.repMer===m.id?' selected':'')+'>'+m.code+' · '+esc(mName(m))+'</option>').join('')+'</select></label>'+
  '<button class="btn pri" id="btn-pdf" data-act="dl-pdf" style="margin-inline-start:auto">'+ic('dl')+t('dl_pdf')+'</button></div>';
}
function periodText(){return S.f.period==='custom'?'<span class="num">'+(S.f.from||'…')+' → '+(S.f.to||'…')+'</span>':t(S.f.period==='all'?'p_all':S.f.period==='month'?'p_month':S.f.period==='90'?'p_90':'p_year')}
function pgMerReport(m){
  const dash='—',rows=[];let rev=0,prof=0,w=0,q=0;
  S.data.codes.forEach(c=>c.sales.forEach(x=>{if(x.merchantId!==m.id||!periodTest(x.date))return;const v=x.wQty*x.wPrice+x.cQty*x.cPrice,pf=v-(x.wQty*c.wCost+x.cQty*c.cCost);rev+=v;prof+=pf;w+=x.wQty;q+=x.cQty;rows.push({c,x,v,pf})}));
  S.data.codes.forEach(c=>{if(c.merchantId!==m.id||!periodTest(c.buy))return;const k=calc(c);if(!k.lumpRev)return;const pf=k.lumpRev-k.lumpCostSold;rev+=k.lumpRev;prof+=pf;rows.push({c,x:{date:c.buy,wQty:0,cQty:0,wPrice:0,cPrice:0},v:k.lumpRev,pf})});
  rows.sort((a,b)=>b.x.date.localeCompare(a.x.date)||b.c.id.localeCompare(a.c.id));
  const pays=S.data.payments.filter(p=>p.merchantId===m.id&&periodTest(p.date)).sort((a,b)=>b.date.localeCompare(a.date));
  const paid=pays.reduce((a,p)=>a+p.amount,0),k=merStats(m);
  const tr=rows.map(r=>'<tr><td class="num">'+r.x.date+'</td><td><b class="mono">'+r.c.id+'</b><small>'+esc(goodsName(r.c))+'</small></td>'+
    '<td class="r">'+(r.x.wQty?num(fmt(r.x.wQty))+'<small>'+num(usd(r.x.wPrice,2))+'</small>':dash)+'</td>'+
    '<td class="r">'+(r.x.cQty?num(fmt(r.x.cQty,1))+'<small>'+num(usd(r.x.cPrice))+'</small>':dash)+'</td>'+
    '<td class="r">'+num(usd(r.v))+'</td><td class="r"><b class="'+profitCls(r.pf)+'">'+num(usd(r.pf))+'</b></td></tr>').join('');
  const pr=pays.map(p=>'<tr><td class="num">'+p.date+'</td><td>'+esc(p.note||dash)+'</td><td class="r"><b class="pos">'+num(usd(p.amount))+'</b></td></tr>').join('');
  return finNav('profit')+head(t('pr_title'),t('mer_report'))+prBar()+
  '<article class="paper" aria-label="'+t('mer_report')+'"><header class="paper-h"><span class="logo" role="img" aria-label="'+t('brand')+'"></span><div><h2>'+bi('mer_report')+'</h2>'+
  '<div class="paper-meta"><span>'+t('rep_mer')+'</span><b>'+esc(mName(m))+' · <span class="mono">'+m.code+'</span></b><span>'+t('f_phone')+'</span><b class="mono">'+esc(m.phone||'—')+'</b><span>'+t('viewed')+'</span><b>'+num(stamp())+'</b><span>'+t('period')+'</span><b>'+periodText()+'</b><span>'+t('prepared_by')+'</span><b>'+esc(pName(me()))+'</b></div></div></header>'+
  '<div class="paper-sum"><div><span>'+t('total_sales')+'</span><b>'+num(usd(rev))+'</b></div><div><span>'+t('paid_in')+'</span><b class="pos">'+num(usd(paid))+'</b></div><div><span>'+t('profit')+'</span><b class="'+profitCls(prof)+'">'+num(usd(prof))+'</b></div><div><span>'+t('bal_all')+'</span><b class="'+(k.balance>0.5?'neg':'')+'">'+num(usd(k.balance))+'</b></div></div>'+
  '<h3>'+t('m_sales')+'</h3>'+(rows.length?'<div class="pscroll"><table class="ptbl"><thead><tr><th>'+t('col_date')+'</th><th>'+t('col_code')+'</th><th class="r">'+t('weight_sold')+'<small>'+t('u_kg')+' · $</small></th><th class="r">'+t('sea_sold')+'<small>CBM · $</small></th><th class="r">'+t('total_sales')+'</th><th class="r">'+t('profit')+'</th></tr></thead><tbody>'+tr+'</tbody><tfoot><tr><td colspan="2">'+t('totals')+' · '+num(rows.length)+'</td><td class="r">'+(w?num(fmt(w)):dash)+'</td><td class="r">'+(q?num(fmt(q,1)):dash)+'</td><td class="r">'+num(usd(rev))+'</td><td class="r">'+num(usd(prof))+'</td></tr></tfoot></table></div>':'<p class="hint">'+t('no_results')+'</p>')+
  '<h3>'+t('payments_title')+'</h3>'+(pays.length?'<div class="pscroll"><table class="ptbl"><thead><tr><th>'+t('col_date')+'</th><th>'+t('d_notes')+'</th><th class="r">'+t('paid_in')+'</th></tr></thead><tbody>'+pr+'</tbody><tfoot><tr><td colspan="2">'+t('totals')+'</td><td class="r">'+num(usd(paid))+'</td></tr></tfoot></table></div>':'<p class="hint">'+t('no_results')+'</p>')+
  '<footer class="paper-foot"><span>'+t('foot_note2')+'</span><span>'+t('brand')+' · '+num(stamp())+'</span></footer></article>';
}

/* ---------- PDF export (renders the report sheet to A4 pages) ---------- */
const loadJs=src=>new Promise((ok,no)=>{const el=document.createElement('script');el.src=src;el.onload=ok;el.onerror=()=>no(new Error('load '+src));document.head.appendChild(el)});
async function tintedLogo(){
  try{
    const el=document.querySelector('.paper .logo');const m=getComputedStyle(el);
    const raw=(m.webkitMaskImage&&m.webkitMaskImage!=='none'?m.webkitMaskImage:m.maskImage)||'';const u=(raw.match(/url\(["']?(.*?)["']?\)/)||[])[1];if(!u)return null;
    const img=await new Promise((ok,no)=>{const i=new Image();i.onload=()=>ok(i);i.onerror=no;i.src=u});
    const c=document.createElement('canvas');c.width=img.naturalWidth;c.height=img.naturalHeight;const x=c.getContext('2d');x.drawImage(img,0,0);x.globalCompositeOperation='source-in';x.fillStyle='#3B2366';x.fillRect(0,0,c.width,c.height);return c.toDataURL('image/png');
  }catch(e){return null}
}
let pdfBusy=false;
async function dlPdf(){
  if(pdfBusy)return;
  let dl=null;try{dl=window.claude&&claude.use?await claude.use('downloads'):null}catch(e){}
  if(!dl)dl={save:async r=>{
    const url=URL.createObjectURL(r.data),a=document.createElement('a');a.href=url;a.download=r.filename;a.rel='noopener';document.body.appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),60000);return {status:'saved'}}};
  pdfBusy=true;const btn=$('#btn-pdf');if(btn){btn.disabled=true}toast(t('pdf_busy'));
  try{
    if(!window.html2canvas)await loadJs('https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js');
    if(!window.jspdf)await loadJs('https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js');
    try{await document.fonts.ready}catch(e){}
    const src=$('.paper'),logo=await tintedLogo(),W=980,SC=2;
    let cuts=[];
    const canvas=await html2canvas(src,{scale:SC,backgroundColor:'#ffffff',useCORS:true,width:W,windowWidth:W+40,onclone:(doc,el)=>{
      el.style.width=W+'px';el.style.maxWidth=W+'px';el.style.boxShadow='none';el.style.border='0';el.style.borderRadius='0';
      el.querySelectorAll('.pscroll').forEach(n=>{n.style.overflow='visible'});
      el.querySelectorAll('[data-noprint]').forEach(n=>{n.style.display='none'});
      const lg=el.querySelector('.logo');if(lg){lg.style.webkitMask='none';lg.style.mask='none';lg.style.backgroundColor='transparent';if(logo){lg.style.backgroundImage='url('+logo+')';lg.style.backgroundSize='contain';lg.style.backgroundRepeat='no-repeat';lg.style.backgroundPosition='center'}}
      const top=el.getBoundingClientRect().top;
      el.querySelectorAll('tr,h3,.paper-sum,.paper-foot').forEach(n=>{cuts.push(Math.round((n.getBoundingClientRect().bottom-top)*SC))});
    }});
    const {jsPDF}=window.jspdf,pdf=new jsPDF({unit:'mm',format:'a4',orientation:'portrait'});
    const PW=210,PH=297,M=10,cw=PW-2*M,ch=PH-2*M-6;
    const pxPer=canvas.width/cw,pageH=Math.floor(ch*pxPer);
    cuts=Array.from(new Set(cuts)).sort((a,b)=>a-b);
    let y=0,pg=0;const pages=[];
    while(y<canvas.height-2){
      let end=Math.min(y+pageH,canvas.height);
      if(end<canvas.height){const ok=cuts.filter(c=>c>y+pageH*0.4&&c<=end);if(ok.length)end=ok[ok.length-1]}
      pages.push([y,end]);y=end;
    }
    pages.forEach((r,i)=>{
      const h=r[1]-r[0],c=document.createElement('canvas');c.width=canvas.width;c.height=h;
      const x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,h);x.drawImage(canvas,0,r[0],canvas.width,h,0,0,canvas.width,h);
      if(i)pdf.addPage();
      pdf.addImage(c.toDataURL('image/jpeg',0.92),'JPEG',M,M,cw,h/pxPer);
      pdf.setFontSize(8);pdf.setTextColor(120);pdf.text('Kurdish Businessman · '+stamp()+' · '+(i+1)+' / '+pages.length,PW/2,PH-8,{align:'center'});
    });
    const mm=S.f.repMer&&mer(S.f.repMer),name=(S.page==='expenses'?'operating-expenses-':S.page==='assets'?'fixed-assets-':mm?'merchant-'+mm.code+'-report-':'profit-report-')+(S.f.period==='custom'?(S.f.from||'start')+'_'+(S.f.to||'end'):iso(today))+'.pdf';
    await dl.save({filename:name,data:pdf.output('blob')});
    toast(t('pdf_done'));
  }catch(e){if(!e||e.code!=='declined'){console.error(e);toast(t('pdf_fail'))}}
  finally{pdfBusy=false;const b=$('#btn-pdf');if(b)b.disabled=false}
}


/* ---------- received weight (stock in) & sales ---------- */
function subnav(cur){
  return '<div class="seg subnav" role="group">'+['shipments','received','sales'].map(p=>'<button data-act="nav" data-id="'+p+'" aria-pressed="'+(cur===p)+'">'+t(p==='shipments'?'nav_shipments':'nav_'+p)+'</button>').join('')+'</div>';
}
function stockTotals(){const a={wR:0,wS:0,cR:0,cS:0,rev:0,n:0};(S.data.receipts||[]).forEach(r=>{a.wR+=+r.w||0;a.cR+=+r.c||0});S.data.codes.forEach(c=>c.sales.forEach(x=>{a.wS+=x.wQty;a.cS+=x.cQty;a.rev+=x.wQty*x.wPrice+x.cQty*x.cPrice;a.n++}));a.wL=Math.round((a.wR-a.wS)*100)/100;a.cL=Math.round((a.cR-a.cS)*100)/100;return a}
function stockStat(label,r,s,unit,d){
  const left=Math.round((r-s)*100)/100,pct=r?Math.min(100,s/r*100):0;
  return '<div class="stat"><span>'+label+'</span><b class="'+(left<0?'neg':'')+'">'+num(fmt(left,d))+' <small>'+unit+'</small></b><div class="bar" style="margin:8px 0 4px"><i style="width:'+pct+'%"></i></div><small class="hint">'+t('st_received')+' '+num(fmt(r,d))+' · '+t('sold')+' '+num(fmt(s,d))+'</small></div>';
}
function pgReceived(){
  const a=stockTotals(),dash='—';
  const rc=(S.data.receipts||[]).slice().sort((x,y)=>y.date.localeCompare(x.date)||String(y.id).localeCompare(String(x.id)));
  const log=rc.length?'<div class="tbl-card cards"><div class="tbl-scroll"><table class="tbl"><thead><tr><th>'+t('col_date')+'</th><th class="end">'+t('col_weight')+'</th><th class="end">'+t('col_sea')+'</th><th>'+t('d_notes')+'</th><th></th></tr></thead><tbody>'+rc.slice(0,120).map(r=>'<tr><td data-l="'+t('col_date')+'" class="num">'+r.date+'</td><td data-l="'+t('col_weight')+'" class="end">'+(r.w?num(fmt(r.w)):dash)+'</td><td data-l="'+t('col_sea')+'" class="end">'+(r.c?num(fmt(r.c,1)):dash)+'</td><td data-l="'+t('d_notes')+'">'+(r.note?'<span class="mono">'+esc(r.note)+'</span>':dash)+'</td><td class="end"><button class="btn sm" data-act="del-receipt" data-id="'+esc(r.id)+'" aria-label="'+t('remove')+'">'+ic('x')+'</button></td></tr>').join('')+'</tbody></table></div></div>':'<div class="tbl-card"><div class="empty">'+t('no_receipts')+'</div></div>';
  return subnav('received')+head(t('rcv_title'),t('rcv_sub'),'<button class="btn pri" data-act="new-receipt">'+ic('plus')+t('new_receipt')+'</button>')+
  '<div class="stats lg">'+stockStat(t('weight_title')+' · '+t('remaining'),a.wR,a.wS,t('u_kg'),0)+stockStat(t('sea_title')+' · '+t('remaining'),a.cR,a.cS,'CBM',1)+'</div>'+
  '<h3 class="sec-h">'+t('rcv_log')+'</h3>'+log;
}
function salesTable(){
  const q=(S.f.sq||'').trim().toLowerCase(),dash='—',rows=[];
  S.data.codes.forEach(c=>c.sales.forEach(x=>{const m=mer(x.merchantId),o=mer(c.merchantId);const hay=(c.id+' '+(m?m.en+' '+m.ku+' '+m.code:'')+' '+(o?o.en+' '+o.ku:'')).toLowerCase();if(!q||hay.includes(q))rows.push({c,x,m})}));
  rows.sort((a,b)=>(b.x.date||'').localeCompare(a.x.date||'')||b.c.id.localeCompare(a.c.id));
  if(!rows.length)return '<div class="tbl-card"><div class="empty">'+t('no_sales')+'</div></div>';
  return '<div class="tbl-card cards"><div class="tbl-scroll"><table class="tbl"><thead><tr><th>'+t('col_date')+'</th><th>'+t('col_code')+'</th><th>'+t('col_merchant')+'</th><th class="end">'+t('weight_sold')+'</th><th class="end">'+t('sea_sold')+'</th><th class="end">'+t('c_total')+'</th><th></th></tr></thead><tbody>'+rows.slice(0,150).map(r=>{const v=r.x.wQty*r.x.wPrice+r.x.cQty*r.x.cPrice;return '<tr><td data-l="'+t('col_date')+'" class="num">'+(r.x.date||dash)+'</td><td data-l="'+t('col_code')+'"><a href="#" class="mono" data-act="open-code" data-id="'+r.c.id+'"><b>'+r.c.id+'</b></a></td><td data-l="'+t('col_merchant')+'"><b>'+esc(mName(r.m))+'</b></td>'+
    '<td data-l="'+t('weight_sold')+'" class="end">'+(r.x.wQty?num(fmt(r.x.wQty))+'<small class="sub2">'+num(usd(r.x.wPrice,2))+'</small>':dash)+'</td><td data-l="'+t('sea_sold')+'" class="end">'+(r.x.cQty?num(fmt(r.x.cQty,1))+'<small class="sub2">'+num(usd(r.x.cPrice))+'</small>':dash)+'</td>'+
    '<td data-l="'+t('c_total')+'" class="end"><b>'+num(usd(v))+'</b></td><td class="end"><button class="btn sm" data-act="del-sale" data-id="'+r.c.id+'|'+r.x.id+'" aria-label="'+t('remove')+'">'+ic('x')+'</button></td></tr>'}).join('')+'</tbody></table></div></div>';
}
function pgSales(){
  const a=stockTotals();
  return subnav('sales')+head(t('sales_page_title'),t('sales_page_sub'),'<button class="btn pri" data-act="new-sale">'+ic('plus')+t('new_sale')+'</button>')+
  '<div class="stats lg"><div class="stat"><span>'+t('weight_sold')+'</span><b>'+num(fmt(a.wS))+' <small>'+t('u_kg')+'</small></b></div><div class="stat"><span>'+t('sea_sold')+'</span><b>'+num(fmt(a.cS,1))+' <small>CBM</small></b></div><div class="stat"><span>'+t('total_sales')+'</span><b>'+num(usd(a.rev))+'</b></div></div>'+
  '<div class="toolbar" style="margin-top:14px"><label class="search" for="sq">'+ic('search')+'<input id="sq" type="search" value="'+esc(S.f.sq||'')+'" placeholder="'+t('sales_search')+'" autocomplete="off"></label></div><div id="sales-list">'+salesTable()+'</div>';
}


/* ---------- fixed assets & operating expenses ---------- */
function finNav(cur){
  return '<div class="seg subnav" role="group">'+['profit','expenses','assets'].map(p=>'<button data-act="nav" data-id="'+p+'" aria-pressed="'+(cur===p)+'">'+t('nav_'+p)+'</button>').join('')+'</div>';
}
function periodControls(){
  return '<label class="fld" for="f-period" style="grid-auto-flow:column;align-items:center;gap:10px"><span>'+t('period')+'</span><select id="f-period">'+[['all','p_all'],['month','p_month'],['90','p_90'],['year','p_year'],['custom','p_custom']].map(o=>'<option value="'+o[0]+'"'+(S.f.period===o[0]?' selected':'')+'>'+t(o[1])+'</option>').join('')+'</select></label>'+
  (S.f.period==='custom'?'<label class="fld" for="f-from" style="grid-auto-flow:column;align-items:center;gap:8px"><span>'+t('d_from')+'</span><input type="date" id="f-from" value="'+S.f.from+'" max="'+S.f.to+'"></label><label class="fld" for="f-to" style="grid-auto-flow:column;align-items:center;gap:8px"><span>'+t('d_to')+'</span><input type="date" id="f-to" value="'+S.f.to+'" min="'+S.f.from+'"></label>':'');
}
function finBar(){return '<div class="pr-bar">'+periodControls()+'<button class="btn pri" id="btn-pdf" data-act="dl-pdf" style="margin-inline-start:auto">'+ic('dl')+t('dl_pdf')+'</button></div>'}
function finPaper(titleKey,summary,body,footKey){
  return '<article class="paper" aria-label="'+t(titleKey)+'"><header class="paper-h"><span class="logo" role="img" aria-label="'+t('brand')+'"></span><div><h2>'+bi(titleKey)+'</h2>'+
  '<div class="paper-meta"><span>'+t('viewed')+'</span><b>'+num(stamp())+'</b><span>'+t('period')+'</span><b>'+periodText()+'</b><span>'+t('prepared_by')+'</span><b>'+esc(pName(me()))+'</b></div></div></header>'+
  '<div class="paper-sum">'+summary+'</div>'+body+'<footer class="paper-foot"><span>'+t(footKey)+'</span><span>'+t('brand')+' · '+num(stamp())+'</span></footer></article>';
}
const sumBox=(label,val,cls)=>'<div><span>'+label+'</span><b'+(cls?' class="'+cls+'"':'')+'>'+val+'</b></div>';
function expRows(){
  const man=S.data.expenses.map(e=>Object.assign({kind:e.cat==='salary'?'salary':'manual'},e));
  return man.filter(r=>periodTest(r.date)).sort((a,b)=>b.date.localeCompare(a.date)||String(b.id).localeCompare(String(a.id)));
}
function pgExpenses(){
  const rows=expRows(),dash='—';
  let total=0,sal=0;const bycat={};rows.forEach(r=>{total+=r.amount;if(r.kind==='salary')sal+=r.amount;bycat[r.cat]=(bycat[r.cat]||0)+r.amount});
  const cats=Object.keys(bycat).sort((a,b)=>bycat[b]-bycat[a]);
  const byEmp={};rows.forEach(r=>{if(r.kind==='salary'){const k=r.memberId||r.title;(byEmp[k]=byEmp[k]||{name:payName(r),n:0,sum:0});byEmp[k].n++;byEmp[k].sum+=r.amount}});
  const emps=Object.values(byEmp).sort((a,b)=>b.sum-a.sum);
  const empTbl=emps.length?'<h3>'+t('by_emp')+'</h3><div class="pscroll"><table class="ptbl"><thead><tr><th>'+t('col_emp')+'</th><th class="r">'+t('col_pays')+'</th><th class="r">'+t('col_amount')+'</th></tr></thead><tbody>'+emps.map(x=>'<tr><td><b>'+esc(x.name)+'</b></td><td class="r">'+num(x.n)+'</td><td class="r">'+num(usd(x.sum))+'</td></tr>').join('')+'</tbody></table></div>':'';
  const body=empTbl+'<h3>'+t('by_cat')+'</h3><div class="pscroll"><table class="ptbl"><thead><tr><th>'+t('f_exp_cat')+'</th><th class="r">'+t('col_amount')+'</th><th class="r">%</th></tr></thead><tbody>'+
    (cats.map(c=>'<tr><td>'+t('cat_'+c)+'</td><td class="r">'+num(usd(bycat[c]))+'</td><td class="r">'+num(fmt(total?bycat[c]/total*100:0,1)+'%')+'</td></tr>').join('')||'<tr><td colspan="3">'+t('no_results')+'</td></tr>')+'</tbody></table></div>'+
    '<h3>'+t('exp_list')+'</h3><div class="pscroll"><table class="ptbl"><thead><tr><th>'+t('col_date')+'</th><th>'+t('f_exp_title')+'</th><th>'+t('f_exp_cat')+'</th><th class="r">'+t('col_amount')+'</th><th data-noprint></th></tr></thead><tbody>'+
    rows.map(r=>'<tr><td class="num">'+r.date+'</td><td><b>'+(r.kind==='salary'?t('cat_salary')+' · ':'')+esc(payName(r))+'</b>'+((r.month||r.notes)?'<small>'+(r.month?num(r.month)+(r.notes?' · ':''):'')+esc(r.notes||'')+'</small>':'')+'</td><td>'+t('cat_'+r.cat)+'</td><td class="r"><b>'+num(usd(r.amount))+'</b></td><td class="r" data-noprint>'+'<button class="btn sm" data-act="edit-expense" data-id="'+r.id+'">'+t('edit')+'</button> <button class="btn sm danger" data-act="del-expense" data-id="'+r.id+'" data-confirm="'+t('confirm_del')+'">'+ic('x')+'</button>'+'</td></tr>').join('')+
    '</tbody><tfoot><tr><td colspan="3">'+t('totals')+' · '+num(rows.length)+'</td><td class="r">'+num(usd(total))+'</td><td data-noprint></td></tr></tfoot></table></div>';
  return finNav('expenses')+head(t('exp_title'),t('exp_sub'),'<button class="btn pri" data-act="pay-salary">'+ic('plus')+t('pay_salary')+'</button> <button class="btn" data-act="new-expense">'+ic('plus')+t('new_expense')+'</button>')+finBar()+
    finPaper('exp_title',sumBox(t('exp_total'),num(usd(total)))+sumBox(t('exp_salaries'),num(usd(sal)))+sumBox(t('exp_other'),num(usd(total-sal)))+sumBox(t('exp_count'),num(rows.length)),body,'exp_foot');
}
function pgAssets(){
  const rows=S.data.assets.filter(a=>periodTest(a.date)).sort((a,b)=>b.date.localeCompare(a.date)||b.id.localeCompare(a.id));
  const total=rows.reduce((x,a)=>x+a.amount,0);
  const body='<h3>'+t('as_list')+'</h3><div class="pscroll"><table class="ptbl"><thead><tr><th>'+t('col_date')+'</th><th>'+t('f_as_name')+'</th><th class="r">'+t('col_amount')+'</th><th data-noprint></th></tr></thead><tbody>'+
    (rows.map(a=>'<tr><td class="num">'+a.date+'</td><td><b>'+esc(a.name)+'</b>'+(a.notes?'<small>'+esc(a.notes)+'</small>':'')+'</td><td class="r"><b>'+num(usd(a.amount))+'</b></td><td class="r" data-noprint><button class="btn sm" data-act="edit-asset" data-id="'+a.id+'">'+t('edit')+'</button> <button class="btn sm danger" data-act="del-asset" data-id="'+a.id+'" data-confirm="'+t('confirm_del')+'">'+ic('x')+'</button></td></tr>').join('')||'<tr><td colspan="4">'+t('no_results')+'</td></tr>')+
    '</tbody><tfoot><tr><td colspan="2">'+t('totals')+' · '+num(rows.length)+'</td><td class="r">'+num(usd(total))+'</td><td data-noprint></td></tr></tfoot></table></div>';
  return finNav('assets')+head(t('as_title'),t('as_sub'),'<button class="btn pri" data-act="new-asset">'+ic('plus')+t('new_asset')+'</button>')+finBar()+
    finPaper('as_title',sumBox(t('as_total'),num(usd(total)))+sumBox(t('as_count'),num(rows.length))+sumBox(t('as_avg'),num(usd(rows.length?total/rows.length:0)))+sumBox(t('as_latest'),rows.length?num(rows[0].date):'—'),body,'as_foot');
}
function payName(r){const m=r.memberId&&S.data.members.find(x=>x.id===r.memberId);return m?pName(m):r.title}
function salMonths(){const out=[],n=new Date(today.getFullYear(),today.getMonth()+1,1);for(let i=0;i<14;i++){const d=new Date(n.getFullYear(),n.getMonth()-i,1);out.push(d.getFullYear()+'-'+pad(d.getMonth()+1,2))}return out}
function isPaid(mid,ym){return S.data.expenses.some(e=>e.cat==='salary'&&e.memberId===mid&&e.month===ym)}
function salaryForm(){
  const ym=iso(today).slice(0,7);
  const rows=S.data.members.map(m=>{const paid=isPaid(m.id,ym);return '<div class="sprow" data-sprow="'+m.id+'" style="display:grid;grid-template-columns:auto 1fr 110px;gap:10px;align-items:center;padding:10px 0;border-bottom:1px solid var(--line,#e7e1d8)">'+
    '<input type="checkbox" data-sp="'+m.id+'" aria-label="'+esc(pName(m))+'"'+(!paid&&m.salary>0?' checked':'')+' style="width:22px;height:22px">'+
    '<div><b>'+esc(pName(m))+'</b> <span class="rolepill" data-sppaid style="'+(paid?'':'display:none')+'">'+t('sal_paid')+'</span></div>'+
    '<input type="number" min="0" step="any" inputmode="decimal" data-spamt="'+m.id+'" value="'+(m.salary||'')+'" aria-label="'+t('col_amount')+'"></div>'}).join('');
  const body='<form id="form-salary" novalidate><div class="sec grid2">'+
    fld('f-smonth',t('f_sal_month'),sel('f-smonth',salMonths().map(x=>[x,x]),ym))+fld('f-sdate',t('f_date'),inp('f-sdate',iso(today),'type="date"'))+
    '<p class="hint full" style="margin:0">'+t('sal_hint')+'</p><div class="full" id="sp-list">'+(rows||t('no_members'))+'</div>'+
    '<div class="full" style="display:flex;justify-content:space-between;font-weight:700"><span>'+t('sal_total')+'</span><span id="sp-total">'+usd(S.data.members.reduce((x,m)=>x+(!isPaid(m.id,ym)&&m.salary>0?m.salary:0),0))+'</span></div>'+
    fld('f-snotes',t('f_notes'),'<textarea id="f-snotes" name="f-snotes"></textarea>','full')+
    '<p class="err full" id="form-err" role="alert"></p></div><div class="sheet-f"><span></span><div class="grp"><button type="button" class="btn" data-act="close">'+t('cancel')+'</button><button type="submit" class="btn pri">'+t('save')+'</button></div></div></form>';
  return sheet('<span class="eyebrow">'+t('nav_expenses')+'</span><h2>'+t('sal_form_title')+'</h2>',body,{narrow:true,label:t('pay_salary')});
}
function salTotalUpdate(){const l=$('#sp-list');if(!l)return;let sum=0;l.querySelectorAll('[data-sprow]').forEach(r=>{const c=r.querySelector('[data-sp]'),a=r.querySelector('[data-spamt]');if(c.checked)sum+=Math.max(0,parseFloat(a.value)||0)});const el=$('#sp-total');if(el)el.textContent=usd(sum)}
function salMonthUpdate(){const ym=$('#f-smonth').value;document.querySelectorAll('#sp-list [data-sprow]').forEach(r=>{const id=r.dataset.sprow,paid=isPaid(id,ym),m=S.data.members.find(x=>x.id===id);r.querySelector('[data-sppaid]').style.display=paid?'':'none';r.querySelector('[data-sp]').checked=!paid&&(parseFloat(r.querySelector('[data-spamt]').value)||0)>0});salTotalUpdate()}
document.addEventListener('change',e=>{const el=e.target;if(el.id==='f-smonth')salMonthUpdate();else if(el.dataset&&(el.dataset.sp||el.dataset.spamt!==undefined))salTotalUpdate()});
document.addEventListener('input',e=>{const el=e.target;if(el.dataset&&el.dataset.spamt!==undefined)salTotalUpdate()});
function expenseForm(e){
  const isNew=!e,d=e||{title:'',cat:'rent',amount:'',date:iso(today),notes:''};
  const body='<form id="form-expense" data-id="'+(isNew?'':e.id)+'" novalidate><div class="sec grid2">'+
    fld('f-etitle',t('f_exp_title'),inp('f-etitle',d.title,'autocomplete="off"'),'full')+
    fld('f-ecat',t('f_exp_cat'),sel('f-ecat',(d.cat==='salary'?['salary'].concat(EXP_CATS):EXP_CATS).map(c=>[c,t('cat_'+c)]),d.cat))+fld('f-eamount',t('f_amount'),inp('f-eamount',d.amount,'type="number" min="0" step="any" inputmode="decimal"'))+
    fld('f-edate',t('f_date'),inp('f-edate',d.date,'type="date"'),'full')+
    fld('f-enotes',t('f_notes'),'<textarea id="f-enotes" name="f-enotes">'+esc(d.notes)+'</textarea>','full')+
    '<p class="err full" id="form-err" role="alert"></p></div><div class="sheet-f"><span></span><div class="grp"><button type="button" class="btn" data-act="close">'+t('cancel')+'</button><button type="submit" class="btn pri">'+t('save')+'</button></div></div></form>';
  return sheet('<span class="eyebrow">'+t('nav_expenses')+'</span><h2>'+t(isNew?'exp_form_new':'exp_form_edit')+'</h2>',body,{narrow:true,label:t('new_expense')});
}
function assetForm(a){
  const isNew=!a,d=a||{name:'',amount:'',date:iso(today),notes:''};
  const body='<form id="form-asset" data-id="'+(isNew?'':a.id)+'" novalidate><div class="sec grid2">'+
    fld('f-aname',t('f_as_name'),inp('f-aname',d.name,'autocomplete="off"'),'full')+
    fld('f-aamount',t('f_amount'),inp('f-aamount',d.amount,'type="number" min="0" step="any" inputmode="decimal"'))+fld('f-adate',t('f_date'),inp('f-adate',d.date,'type="date"'))+
    fld('f-anotes',t('f_notes'),'<textarea id="f-anotes" name="f-anotes">'+esc(d.notes)+'</textarea>','full')+
    '<p class="err full" id="form-err" role="alert"></p></div><div class="sheet-f"><span></span><div class="grp"><button type="button" class="btn" data-act="close">'+t('cancel')+'</button><button type="submit" class="btn pri">'+t('save')+'</button></div></div></form>';
  return sheet('<span class="eyebrow">'+t('nav_assets')+'</span><h2>'+t(isNew?'as_form_new':'as_form_edit')+'</h2>',body,{narrow:true,label:t('new_asset')});
}

/* ---------- debts ---------- */
function debtPill(k){return k.balance<=0.5?'<span class="pill st4">'+t('debt_settled')+'</span>':k.paid>0?'<span class="pill st1">'+t('debt_part')+'</span>':'<span class="pill bad">'+t('debt_none')+'</span>'}
function debtTable(){
  const q=S.f.dq.trim().toLowerCase();
  const list=S.data.merchants.map(m=>({m,k:merStats(m)})).filter(x=>(x.k.bought>0||x.k.paid>0)&&(!q||(x.m.en+' '+x.m.ku+' '+x.m.phone+' '+x.m.code).toLowerCase().includes(q))&&(!S.f.owing||x.k.balance>0.5)).sort((a,b)=>b.k.balance-a.k.balance);
  if(!list.length)return '<div class="tbl-card"><div class="empty">'+t('no_results')+'</div></div>';
  const rows=list.map(x=>'<tr data-act="open-merchant" data-id="'+x.m.id+'" tabindex="0"><td class="mainc cell-main"><b>'+esc(mName(x.m))+'</b><small>'+t('m_code')+' <span class="mono">'+x.m.code+'</span> · '+esc(pickL(CITIES[x.m.city]||['—','—']))+'</small></td><td data-l="'+t('total_sales')+'" class="end">'+num(usd(x.k.bought))+'</td><td data-l="'+t('col_paid')+'" class="end">'+num(usd(x.k.paid))+'</td><td data-l="'+t('col_balance')+'" class="end"><b class="'+(x.k.balance>0.5?'neg':x.k.balance<-0.5?'pos':'')+'">'+num(usd(x.k.balance))+'</b></td><td data-l="'+t('col_last')+'">'+(x.k.last?num(x.k.last):'—')+'</td><td data-l="'+t('col_status')+'">'+debtPill(x.k)+'</td></tr>').join('');
  return '<div class="tbl-card cards"><div class="tbl-scroll"><table class="tbl"><thead><tr><th>'+t('col_name')+'</th><th class="end">'+t('total_sales')+'</th><th class="end">'+t('col_paid')+'</th><th class="end">'+t('col_balance')+'</th><th>'+t('col_last')+'</th><th>'+t('col_status')+'</th></tr></thead><tbody>'+rows+'</tbody></table></div></div>';
}
function pgDebts(){
  let sold=0,paid=0;S.data.merchants.forEach(m=>{const k=merStats(m);sold+=k.bought;paid+=k.paid});
  const out=sold-paid,pct=sold?Math.min(100,paid/sold*100):0;
  return head(t('debts_title'),t('debts_sub'),'<button class="btn pri" data-act="new-payment">'+ic('plus')+t('add_payment')+'</button>')+
  '<div class="stats lg"><div class="stat"><span>'+t('total_sales')+'</span><b>'+num(usd(sold))+'</b></div>'+
  '<div class="stat"><span>'+t('paid_in')+'</span><b class="pos">'+num(usd(paid))+'</b><div class="bar" style="margin:8px 0 4px"><i style="width:'+pct+'%"></i></div><small class="hint">'+num(fmt(pct,0)+'%')+' '+t('collected')+'</small></div>'+
  '<div class="stat"><span>'+t('outstanding')+'</span><b class="'+(out>0.5?'neg':'')+'">'+num(usd(out))+'</b></div></div>'+
  '<div class="toolbar" style="margin-top:14px"><label class="search" for="dq">'+ic('search')+'<input id="dq" type="search" value="'+esc(S.f.dq)+'" placeholder="'+t('mer_search')+'" autocomplete="off"></label><button class="chip" data-act="fowing" aria-pressed="'+S.f.owing+'">'+t('f_owing')+'</button></div><div id="debt-list">'+debtTable()+'</div>';
}
function payForm(mid){
  const body='<form id="form-pay" novalidate><div class="sec grid2">'+
    fld('f-pmer',t('nav_merchants'),sel('f-pmer',[['',t('pick_merchant')]].concat(S.data.merchants.slice().sort((a,b)=>mName(a).localeCompare(mName(b))).map(m=>[m.id,m.code+' · '+mName(m)])),mid||''),'full')+
    fld('f-pamt',t('f_amount'),inp('f-pamt','','type="number" min="0" step="any" inputmode="decimal"'))+fld('f-pdate',t('f_date'),inp('f-pdate',iso(today),'type="date"'))+
    fld('f-pnote',t('f_notes'),inp('f-pnote','','autocomplete="off"'),'full')+
    '<p class="err full" role="alert"></p></div><div class="sheet-f"><span></span><div class="grp"><button type="button" class="btn" data-act="close">'+t('cancel')+'</button><button type="submit" class="btn pri">'+t('save')+'</button></div></div></form>';
  return sheet('<span class="eyebrow">'+t('payments_title')+'</span><h2>'+t('pay_title')+'</h2>',body,{narrow:true,label:t('pay_title')});
}
function pwForm(m){
  const body='<form id="form-pw" data-id="'+m.id+'" novalidate><div class="sec">'+
    fld('f-rpw',t('f_new'),inp('f-rpw','','type="password" autocomplete="new-password"'))+
    '<p class="err" role="alert"></p></div><div class="sheet-f"><span></span><div class="grp"><button type="button" class="btn" data-act="close">'+t('cancel')+'</button><button type="submit" class="btn pri">'+t('save')+'</button></div></div></form>';
  return sheet('<span class="eyebrow">'+t('reset_pw')+'</span><h2>'+t('reset_pw_title',{n:esc(pName(m))})+'</h2>',body,{narrow:true,label:t('reset_pw')});
}

/* ---------- profile ---------- */
function pgProfile(){
  const u=S.data.members.find(x=>x.id===S.auth)||me(),mgr=u.role==='manager';
  const tags=mgr?'<span class="rolepill">'+t('all_access')+'</span>':(SECTIONS.filter(s=>u.perms[s]).map(s=>'<span class="rolepill">'+t('perm_'+s)+'</span>').join('')||'<span class="hint">'+t('no_sections')+'</span>');
  return head(t('profile_title'),t('profile_sub'))+
  '<div class="prof"><section class="card prof-id">'+av(u,'xl')+'<div><b>'+esc(pName(u))+'</b><span class="hint mono">'+esc(u.email)+'</span></div><span class="rolepill">'+t(mgr?'role_manager':'role_admin')+'</span>'+
  '<div class="acts"><label class="btn file">'+t('change_photo')+'<input id="f-photo" type="file" accept="image/*" class="sr"></label>'+(u.photo?'<button class="btn danger" data-act="rmphoto">'+t('remove_photo')+'</button>':'')+'</div><p class="hint">'+t('photo_hint')+'</p>'+
  '<div class="access"><span class="eyebrow">'+t('your_access')+'</span><div class="tags">'+tags+'</div></div></section>'+
  '<div class="prof-col"><section class="card"><header><h3>'+t('details')+'</h3></header><form id="form-profile" class="stack" novalidate><div class="grid2">'+
  fld('f-pname-ku',t('f_name_ku'),inp('f-pname-ku',u.ku,'autocomplete="off" dir="rtl"'))+fld('f-pname-en',t('f_name_en'),inp('f-pname-en',u.en,'autocomplete="off" dir="ltr"'))+
  fld('f-pemail',t('f_email'),inp('f-pemail',u.email,'dir="ltr" readonly'),'full')+'</div><p class="err" role="alert"></p><div><button type="submit" class="btn pri">'+t('save')+'</button></div></form></section>'+
  '<section class="card"><header><h3>'+t('password_title')+'</h3></header><form id="form-pass" class="stack" novalidate>'+
  fld('f-cur',t('f_cur'),inp('f-cur','','type="password" autocomplete="current-password"'))+
  '<div class="grid2">'+fld('f-new',t('f_new'),inp('f-new','','type="password" autocomplete="new-password"'))+fld('f-new2',t('f_new2'),inp('f-new2','','type="password" autocomplete="new-password"'))+'</div>'+
  '<p class="err" role="alert"></p><div><button type="submit" class="btn pri">'+t('save')+'</button></div></form></section></div></div>';
}
function readPhoto(file,cb){
  const fr=new FileReader();
  fr.onload=()=>{const img=new Image();img.onload=()=>{const n=256,c=document.createElement('canvas');c.width=c.height=n;const x=c.getContext('2d'),m=Math.min(img.width,img.height);x.drawImage(img,(img.width-m)/2,(img.height-m)/2,m,m,0,0,n,n);cb(c.toDataURL('image/jpeg',.86))};img.onerror=()=>cb(null);img.src=fr.result};
  fr.onerror=()=>cb(null);fr.readAsDataURL(file);
}

/* ---------- team ---------- */
function pgTeam(){

  const cards=S.data.members.map(m=>{
    const mgr=m.role==='manager';
    const perms=mgr?'<p class="hint" style="margin-bottom:6px">'+t('all_access')+'</p>':SECTIONS.map(s=>'<div class="perm"><span>'+t('perm_'+s)+'</span><label class="switch"><input type="checkbox" data-perm="'+m.id+':'+s+'"'+(m.perms[s]?' checked':'')+' aria-label="'+t('perm_'+s)+'"><span class="track"></span></label></div>').join('')+'<div class="perm"><span>'+t('perm_team')+'</span><span class="lock">'+ic('lock')+t('mgr_only')+'</span></div>';
    const acts=mgr?'':'<div class="acts"><button class="btn sm" data-act="preview" data-id="'+m.id+'">'+ic('chev','flip')+t('preview_as')+'</button><button class="btn sm" data-act="resetpw" data-id="'+m.id+'">'+t('reset_pw')+'</button><button class="btn sm danger" data-act="rm-member" data-id="'+m.id+'" data-confirm="'+t('confirm_del')+'">'+t('remove')+'</button></div>';
    return '<section class="card mcard"><div class="head">'+av(m)+'<div><b>'+esc(pName(m))+'</b><small class="mono" style="font-size:12.5px">'+esc(m.email)+'</small></div><span class="rolepill">'+t(mgr?'role_manager':'role_admin')+'</span></div><div class="perm sal"><span>'+t('f_salary')+'</span><input type="number" min="0" step="any" inputmode="decimal" data-salary="'+m.id+'" value="'+(m.salary||'')+'" aria-label="'+t('f_salary')+'"></div>'+perms+acts+'</section>';
  }).join('');
  return head(t('team_title'),t('team_sub'),'<button class="btn pri" data-act="new-member">'+ic('plus')+t('add_member')+'</button>')+'<div class="members">'+cards+'</div>';
}

/* ---------- modal + toast ---------- */
function renderModal(){
  const root=$('#modal-root'),m=S.modal;
  const old=root.firstElementChild,keep=old?old.scrollTop:0;
  if(!m){root.innerHTML='';document.body.style.overflow='';return}
  let h='';
  if(m.type==='code'){const c=codeOf(m.id);h=c?codeSheet(c):''}
  else if(m.type==='codeForm')h=codeForm(m.id?codeOf(m.id):null);
  else if(m.type==='saleForm')h=saleForm(m.id?codeOf(m.id):null);
  else if(m.type==='receiptForm')h=receiptForm();
  else if(m.type==='salaryForm')h=salaryForm();
  else if(m.type==='expenseForm')h=expenseForm(m.id?S.data.expenses.find(x=>x.id===m.id):null);
  else if(m.type==='assetForm')h=assetForm(m.id?S.data.assets.find(x=>x.id===m.id):null);
  else if(m.type==='merchant'){const x=mer(m.id);h=x?merSheet(x):''}
  else if(m.type==='merchantForm')h=merchantForm(m.id?mer(m.id):null);
  else if(m.type==='memberForm')h=memberForm();
  else if(m.type==='payForm')h=payForm(m.id);
  else if(m.type==='pwForm'){const x=S.data.members.find(y=>y.id===m.id);h=x?pwForm(x):''}
  root.innerHTML=h;document.body.style.overflow=h?'hidden':'';
  const back=root.firstElementChild;
  if(back){back.scrollTop=m._fresh?0:keep;const f=back.querySelector('form input:not([readonly]),form select');if(f&&m._fresh)f.focus({preventScroll:true})}
  if(m)m._fresh=false;
}
function openModal(m){m._fresh=true;S.modal=m;renderModal()}
function closeModal(){const b=S.modal&&S.modal.back;S.modal=b?Object.assign({},b):null;if(S.modal)S.modal._fresh=true;renderModal()}
let toastT;
function toast(msg){const el=$('#toast');el.textContent=msg;el.hidden=false;clearTimeout(toastT);toastT=setTimeout(()=>{el.hidden=true},2200)}
function refresh(){save();renderPage();renderModal()}
function go(p){S.page=p;S.modal=null;try{location.hash=p}catch(e){}document.body.style.overflow='';renderApp();window.scrollTo(0,0)}
function setLang(l){S.lang=l;save();renderApp()}

/* ---------- events ---------- */
document.addEventListener('click',e=>{
  const el=e.target.closest('[data-act]');
  if(!el){if(e.target.classList&&e.target.classList.contains('modal-back'))closeModal();return}
  const act=el.dataset.act,id=el.dataset.id;
  if(el.tagName==='A')e.preventDefault();
  const armed=()=>{
    if(el.classList.contains('armed'))return true;
    el.classList.add('armed');el.dataset.orig=el.innerHTML;el.textContent=el.dataset.confirm;
    setTimeout(()=>{if(el.isConnected&&el.classList.contains('armed')){el.classList.remove('armed');el.innerHTML=el.dataset.orig}},4000);
    return false;
  };
  switch(act){
    case 'nav':go(id);break;
    case 'lang':setLang(id);break;
    case 'fstatus':S.f.status=id;renderPage();break;
    case 'gostatus':S.f.status=id;S.f.q='';S.f.mode='all';go('shipments');break;
    case 'open-code':openModal({type:'code',id,back:S.modal&&S.modal.type==='merchant'?S.modal:null});break;
    case 'open-merchant':openModal({type:'merchant',id});break;
    case 'new-code':openModal({type:'codeForm'});break;
    case 'edit-code':openModal({type:'codeForm',id,back:{type:'code',id}});break;
    case 'new-sale':openModal({type:'saleForm',id,back:id?{type:'code',id}:null});break;
    case 'pay-salary':openModal({type:'salaryForm',back:null});break;
    case 'new-expense':openModal({type:'expenseForm',back:null});break;
    case 'edit-expense':openModal({type:'expenseForm',id,back:null});break;
    case 'del-expense':if(armed()){S.data.expenses=S.data.expenses.filter(x=>x.id!==id);refresh();toast(t('deleted'))}break;
    case 'new-asset':openModal({type:'assetForm',back:null});break;
    case 'edit-asset':openModal({type:'assetForm',id,back:null});break;
    case 'del-asset':if(armed()){S.data.assets=S.data.assets.filter(x=>x.id!==id);refresh();toast(t('deleted'))}break;
    case 'new-receipt':openModal({type:'receiptForm',back:null});break;
    case 'del-receipt':{const r=S.data.receipts.find(x=>String(x.id)===id);if(!r)break;const a=stockTotals();if(a.wR-(+r.w||0)<a.wS-1e-9||a.cR-(+r.c||0)<a.cS-1e-9){toast(t('err_below_sold'));break}S.data.receipts=S.data.receipts.filter(x=>x!==r);refresh();toast(t('deleted'));break}
    case 'new-merchant':openModal({type:'merchantForm'});break;
    case 'mer-report':S.f.repMer=id;closeModal();S.page='profit';renderApp();window.scrollTo(0,0);break;
    case 'edit-merchant':openModal({type:'merchantForm',id,back:{type:'merchant',id}});break;
    case 'new-member':openModal({type:'memberForm'});break;
    case 'new-payment':openModal({type:'payForm',id:id||'',back:S.modal&&S.modal.type==='merchant'?{type:'merchant',id:S.modal.id}:null});break;
    case 'del-payment':S.data.payments=S.data.payments.filter(p=>p.id!==id);refresh();toast(t('deleted'));break;
    case 'pick-mer':{const h=$('#f-cmer');h.value=id;h.dispatchEvent(new Event('input',{bubbles:true}));mpSync();const n=$('#f-track');if(n)n.focus();break}
    case 'dl-pdf':dlPdf();break;
    case 'fowing':S.f.owing=!S.f.owing;renderPage();break;
    case 'resetpw':openModal({type:'pwForm',id});break;
    case 'rmphoto':{const u=S.data.members.find(x=>x.id===S.auth);u.photo=null;save();renderApp();break}
    case 'close':closeModal();break;
    case 'fill':{const m=S.data.members.find(x=>x.id===id);$('#f-email').value=m.email;$('#f-pass').value=m.pw;$('#form-err').textContent='';break}
    case 'togglepw':{const i=$('#f-pass'),h=i.type==='password';i.type=h?'text':'password';el.textContent=t(h?'hide':'show');break}
    case 'logout':S.auth=S.user=null;S.modal=null;S.page='dashboard';try{localStorage.removeItem('kb-session')}catch(x){}renderApp();window.scrollTo(0,0);break;
    case 'del-sale':{const p=id.split('|'),c=codeOf(p[0]);c.sales=c.sales.filter(s=>s.id!==p[1]);refresh();toast(t('deleted'));break}
    case 'advance':{const c=codeOf(id);if(c.status<4){c.status++;c.dates[c.status]=iso(today);refresh()}break}
    case 'undo':{const c=codeOf(id);if(c.status>0){c.dates[c.status]=null;c.status--;refresh()}break}
    case 'del-code':if(armed()){S.data.codes=S.data.codes.filter(c=>c.id!==id);S.modal=null;refresh();toast(t('deleted'))}break;
    case 'rm-member':if(armed()){S.data.members=S.data.members.filter(m=>m.id!==id);refresh();toast(t('deleted'))}break;
    case 'preview':S.user=id;S.modal=null;S.page=PAGES.find(can)||'dashboard';renderApp();window.scrollTo(0,0);break;
    case 'backmgr':S.user=S.auth;S.page='team';renderApp();window.scrollTo(0,0);break;
    case 'reset':S.data=seed();ensureReceipts(S.data);ensureFinance(S.data);S.user=S.auth;S.f={q:'',status:'all',mode:'all',mq:'',period:'all',from:'',to:'',repMer:'',dq:'',owing:false};S.modal=null;if(!S.data.members.find(m=>m.id===S.auth)){S.auth=S.user=null;try{localStorage.removeItem('kb-session')}catch(x){}}save();renderApp();toast(t('reset_done'));break;
    case 'copy':{
      const txt=el.dataset.text,ok=()=>toast(t('copied'));
      const fb=()=>{const ta=document.createElement('textarea');ta.value=txt;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();try{document.execCommand('copy');ok()}catch(x){toast(txt)}ta.remove()};
      try{navigator.clipboard.writeText(txt).then(ok,fb)}catch(x){fb()}
      break}
  }
});
document.addEventListener('keydown',e=>{
  if(e.key==='Escape'&&S.modal){closeModal();return}
  if(e.key==='Enter'&&e.target.matches&&e.target.matches('tr[data-act]'))e.target.click();
});
document.addEventListener('input',e=>{
  if(e.target.id==='q'){S.f.q=e.target.value;$('#code-list').innerHTML=codeTable()}
  else if(e.target.id==='mq'){S.f.mq=e.target.value;$('#mer-list').innerHTML=merTable()}
  else if(e.target.id==='mp-q'){const l=$('#mp-list');l.innerHTML=merItems(e.target.value);l.hidden=false}
  else if(e.target.id==='f-cmer'){const m=findMer(e.target.value),o=$('#code-prev'),eid=e.target.form&&e.target.form.dataset.id,cur=eid?codeOf(eid):null;if(o)o.textContent=m?(cur&&cur.merchantId===m.id?cur.id:nextCodeFor(m.id)):'—'}
  else if(e.target.id==='sq'){S.f.sq=e.target.value;$('#sales-list').innerHTML=salesTable()}
  else if(e.target.id==='dq'){S.f.dq=e.target.value;$('#debt-list').innerHTML=debtTable()}
});
const mpSync=()=>{const h=$('#f-cmer'),q=$('#mp-q'),l=$('#mp-list');if(!h||!q)return;const m=findMer(h.value);q.value=m?merLabel(m):'';if(l)l.hidden=true};
document.addEventListener('focusin',e=>{if(e.target.id==='mp-q'){const l=$('#mp-list');e.target.select();l.innerHTML=merItems('');l.hidden=false}});
document.addEventListener('focusout',e=>{if(e.target.id==='mp-q')setTimeout(()=>{if(document.activeElement&&document.activeElement.id==='mp-q')return;const q=$('#mp-q'),h=$('#f-cmer');if(!q||!h)return;const typed=findMer(q.value);if(typed&&typed.code+''!==h.value){h.value=typed.code;h.dispatchEvent(new Event('input',{bubbles:true}))}mpSync()},120)});
document.addEventListener('pointerdown',e=>{if(e.target.closest&&e.target.closest('#mp-list'))e.preventDefault()});
document.addEventListener('keydown',e=>{if(e.target.id==='mp-q'&&e.key==='Enter'){e.preventDefault();const f=$('#mp-list .mp-i');if(f)f.click()}});
document.addEventListener('change',e=>{
  const el=e.target;
  if(el.id==='f-scode'){const c=codeOf(el.value);if(c){const m=$('#f-merchant');if(m&&!m.value)m.value=c.merchantId||'';const wp=$('#f-swp'),cp=$('#f-scp');if(wp&&!wp.value&&c.wCost)wp.value=+(c.wCost*1.2).toFixed(2);if(cp&&!cp.value&&c.cCost)cp.value=Math.round(c.cCost*1.2)}}
  else if(el.id==='flt-mode'){S.f.mode=el.value;renderPage()}
  else if(el.id==='f-period'){S.f.period=el.value;if(el.value==='custom'&&!S.f.from&&!S.f.to){S.f.to=iso(today);S.f.from=iso(addDays(today,-30))}renderPage()}
  else if(el.id==='f-repmer'){S.f.repMer=el.value;renderPage()}
  else if(el.id==='f-from'||el.id==='f-to'){S.f[el.id==='f-from'?'from':'to']=el.value;if(S.f.from&&S.f.to&&S.f.from>S.f.to){const x=S.f.from;S.f.from=S.f.to;S.f.to=x}renderPage()}
  else if(el.id==='f-photo'){const file=el.files&&el.files[0];if(!file)return;if(!/^image\//.test(file.type)){toast(t('err_photo'));return}readPhoto(file,url=>{if(!url){toast(t('err_photo'));return}const u=S.data.members.find(x=>x.id===S.auth);u.photo=url;save();renderApp();toast(t('photo_saved'))})}
  else if(el.dataset&&el.dataset.salary){const m=S.data.members.find(x=>x.id===el.dataset.salary);if(m){m.salary=Math.max(0,parseFloat(el.value)||0);save();toast(t('saved'))}}
  else if(el.dataset&&el.dataset.perm){const p=el.dataset.perm.split(':'),m=S.data.members.find(x=>x.id===p[0]);m.perms[p[1]]=el.checked?1:0;save();toast(t('saved'))}
});
document.addEventListener('submit',e=>{
  e.preventDefault();
  const f=e.target,v=n=>f.elements[n]?f.elements[n].value.trim():'',pn=n=>{const x=parseFloat(v(n));return isFinite(x)&&x>0?x:0},err=m=>{const x=f.querySelector('.err');if(x)x.textContent=m?t(m):''};
  if(f.id==='form-login'){
    const em=v('f-email').toLowerCase(),pw=f.elements['f-pass'].value;
    if(!em||!pw)return err('err_login_empty');
    const m=S.data.members.find(x=>x.email.toLowerCase()===em&&x.pw===pw);
    if(!m)return err('err_login');
    S.auth=S.user=m.id;try{localStorage.setItem('kb-session',m.id)}catch(x){}
    S.page=PAGES.find(can)||'dashboard';renderApp();window.scrollTo(0,0);return;
  }
  if(f.id==='form-code'){
    const rec={merchantId:(findMer(v('f-cmer'))||{}).id||'',track:v('f-track'),mode:v('f-mode'),goods:v('f-goods'),origin:v('f-origin'),dest:v('f-dest'),buy:v('f-buy')||iso(today),wCost:pn('f-wp'),cCost:pn('f-cp'),tCost:pn('f-tcost'),tSale:pn('f-tsale'),notes:v('f-notes')};
    if(!rec.merchantId)return err('err_pick');
    const id=f.dataset.id;
    if(id){const c=codeOf(id);const moved=c.merchantId!==rec.merchantId;Object.assign(c,rec);if(moved)c.id=nextCodeFor(rec.merchantId);c.dates[0]=rec.buy;S.modal={type:'code',id:c.id,_fresh:true};refresh();toast(t('saved'))}
    else{const nid=nextCodeFor(rec.merchantId);S.data.codes.push(Object.assign({id:nid,status:0,dates:[rec.buy,null,null,null,null],sales:[],wQty:0,cQty:0},rec));S.modal={type:'code',id:nid,_fresh:true};S.f.status='all';S.f.q='';refresh();toast(t('code_created'))}
  }else if(f.id==='form-sale'){
    const c=codeOf(f.dataset.id||v('f-scode')),mid=v('f-merchant'),wq=pn('f-swq'),cq=pn('f-scq'),wp=pn('f-swp'),cp=pn('f-scp');
    if(!c)return err('err_code');
    const k=calc(c);
    if(!mid)return err('err_pick');
    {const a=stockTotals();if(wq>a.wL+1e-9||cq>a.cL+1e-9)return err('err_exceed');}
    c.sales.push({id:'S'+Date.now().toString(36),merchantId:mid,wQty:wq,wPrice:wq?wp:0,cQty:cq,cPrice:cq?cp:0,date:iso(today)});
    S.modal=f.dataset.id?{type:'code',id:c.id,_fresh:true}:null;refresh();toast(t('sale_added'));
  }else if(f.id==='form-salary'){
    const ym=v('f-smonth'),date=v('f-sdate')||iso(today),notes=v('f-snotes'),out=[];
    f.querySelectorAll('[data-sprow]').forEach(r=>{const id=r.dataset.sprow,m=S.data.members.find(x=>x.id===id),a=parseFloat(r.querySelector('[data-spamt]').value)||0;if(m&&r.querySelector('[data-sp]').checked&&a>0)out.push({id:'SP'+Date.now().toString(36)+id,title:m.en||m.ku,cat:'salary',memberId:id,month:ym,amount:a,date,notes})});
    if(!out.length)return err('err_sal_pick');
    out.forEach(x=>S.data.expenses.push(x));S.modal=null;refresh();toast(t('sal_added'));
  }else if(f.id==='form-expense'){
    const rec={title:v('f-etitle'),cat:v('f-ecat'),amount:pn('f-eamount'),date:v('f-edate')||iso(today),notes:v('f-enotes')};
    if(!rec.title)return err('err_exp_title');
    if(!(rec.amount>0))return err('err_amount');
    const id=f.dataset.id;
    if(id){Object.assign(S.data.expenses.find(x=>x.id===id),rec)}else{S.data.expenses.push(Object.assign({id:'E'+Date.now().toString(36)},rec))}
    S.modal=null;refresh();toast(t(id?'saved':'exp_added'));
  }else if(f.id==='form-asset'){
    const rec={name:v('f-aname'),amount:pn('f-aamount'),date:v('f-adate')||iso(today),notes:v('f-anotes')};
    if(!rec.name)return err('err_as_name');
    if(!(rec.amount>0))return err('err_amount');
    const id=f.dataset.id;
    if(id){Object.assign(S.data.assets.find(x=>x.id===id),rec)}else{S.data.assets.push(Object.assign({id:'A'+Date.now().toString(36)},rec))}
    S.modal=null;refresh();toast(t(id?'saved':'as_added'));
  }else if(f.id==='form-receipt'){
    const w=pn('f-rw'),q=pn('f-rc');
    if(!w&&!q)return err('err_rcv');
    S.data.receipts.push({id:'R'+Date.now().toString(36),date:v('f-rdate')||iso(today),w,c:q,note:v('f-rnote')});
    S.modal=null;refresh();toast(t('receipt_added'));
  }else if(f.id==='form-merchant'){
    const rec={ku:v('f-name-ku'),en:v('f-name-en'),phone:v('f-phone'),city:v('f-city'),notes:v('f-notes')};
    if(!rec.ku&&!rec.en)return err('err_name');
    const id=f.dataset.id,mc=parseInt(v('f-mcode'),10);
    if(!(mc>0)||S.data.merchants.some(x=>x.code===mc&&x.id!==id))return err('err_mcode');
    rec.code=mc;
    if(id){Object.assign(mer(id),rec);S.modal={type:'merchant',id,_fresh:true}}
    else{const nid='M'+pad(Math.max(0,...S.data.merchants.map(m=>parseInt(m.id.slice(1),10)||0))+1);S.data.merchants.push(Object.assign({id:nid},rec));S.f.mq='';S.modal=null}
    refresh();toast(t('saved'));
  }else if(f.id==='form-pay'){
    const mid=v('f-pmer'),amt=pn('f-pamt');
    if(!mid)return err('err_pick');
    if(!amt)return err('err_amount');
    S.data.payments.push({id:'P'+Date.now().toString(36),merchantId:mid,amount:amt,date:v('f-pdate')||iso(today),note:v('f-pnote')});
    const b=S.modal&&S.modal.back;S.modal=b?{type:b.type,id:b.id,_fresh:true}:null;refresh();toast(t('payment_added'));
  }else if(f.id==='form-profile'){
    const u=S.data.members.find(x=>x.id===S.auth),ku=v('f-pname-ku'),en=v('f-pname-en');
    if(!ku&&!en)return err('err_name');
    u.ku=ku||en;u.en=en||ku;save();renderApp();toast(t('saved'));
  }else if(f.id==='form-pass'){
    const u=S.data.members.find(x=>x.id===S.auth),cur=f.elements['f-cur'].value,n1=f.elements['f-new'].value,n2=f.elements['f-new2'].value;
    if(cur!==u.pw)return err('err_pw_wrong');
    if(n1.length<6)return err('err_pw_short');
    if(n1!==n2)return err('err_pw_match');
    u.pw=n1;save();renderPage();toast(t('pw_changed'));
  }else if(f.id==='form-pw'){
    const m=S.data.members.find(x=>x.id===f.dataset.id),p=f.elements['f-rpw'].value;
    if(p.length<6)return err('err_pw_short');
    m.pw=p;S.modal=null;refresh();toast(t('pw_changed'));
  }else if(f.id==='form-member'){
    const name=v('f-mname'),email=v('f-memail');
    const mpw=f.elements['f-mpw'].value;
    if(!name||!email)return err('err_member');
    if(mpw.length<6)return err('err_pw_short');
    if(S.data.members.some(x=>x.email.toLowerCase()===email.toLowerCase()))return err('err_email_dup');
    const perms={dashboard:0,shipments:0,merchants:0,profit:0,team:0};
    f.querySelectorAll('input[name="perm"]:checked').forEach(i=>{perms[i.value]=1});
    S.data.members.push({id:'U'+Date.now().toString(36),en:name,ku:name,email,role:'admin',pw:mpw,perms,salary:pn('f-msalary'),since:iso(today).slice(0,7)});
    S.modal=null;refresh();toast(t('member_added'));
  }
});

/* ---------- start ---------- */
load();
try{const h=(location.hash||'').slice(1);if(PAGES.indexOf(h)>-1)S.page=h}catch(e){}
renderApp();
})();
